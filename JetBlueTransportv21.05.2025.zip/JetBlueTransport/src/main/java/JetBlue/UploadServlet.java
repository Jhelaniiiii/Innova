package JetBlue;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import java.util.Date;

@WebServlet("/customer/upload")
@MultipartConfig(
    maxFileSize = 2097152,       // 2MB
    maxRequestSize = 4194304,    // 4MB
    fileSizeThreshold = 1048576  // 1MB
)
public class UploadServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Enhanced debug logging
        System.out.println("=== UPLOAD REQUEST STARTED ===");
        System.out.println("Temp dir: " + System.getProperty("java.io.tmpdir"));
        
        HttpSession session = request.getSession(false);
        if (session == null) {
            System.out.println("No valid session found");
            response.sendRedirect(request.getContextPath() + "/customer/verify.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        if (email == null || email.isEmpty()) {
            session.setAttribute("error", "No active session found");
            System.out.println("No email in session");
            response.sendRedirect(request.getContextPath() + "/customer/verify.jsp");
            return;
        }

        System.out.println("Processing file upload for: " + email);

        // CSRF protection
        try {
            String sessionToken = (String) session.getAttribute("csrfToken");
            String requestToken = request.getParameter("csrfToken");
            
            if (sessionToken == null || !sessionToken.equals(requestToken)) {
                System.out.println("CSRF token validation failed");
                session.setAttribute("error", "Invalid request");
                response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                return;
            }
        } catch (Exception e) {
            System.out.println("CSRF verification error: " + e.getMessage());
            session.setAttribute("error", "Security verification failed");
            response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
            return;
        }

        try {
            // Verify multipart request
            String contentType = request.getContentType();
            if (contentType == null || !contentType.toLowerCase().startsWith("multipart/form-data")) {
                System.out.println("Invalid content type: " + contentType);
                session.setAttribute("error", "Invalid form data");
                response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                return;
            }

            // Get file part
            Part filePart = request.getPart("profilePicture");
            if (filePart == null || filePart.getSize() == 0) {
                System.out.println("No file received or empty file");
                session.setAttribute("error", "Please select a valid file");
                response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                return;
            }

            // File validation
            String fileName = filePart.getSubmittedFileName();
            System.out.println("Uploading file: " + fileName + " (" + filePart.getSize() + " bytes)");
            
            if (fileName == null || !fileName.matches("(?i).*\\.(jpg|jpeg|png)$")) {
                System.out.println("Invalid file type: " + fileName);
                session.setAttribute("error", "Only JPG/JPEG/PNG files allowed");
                response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                return;
            }

            if (filePart.getSize() > 2000000) {
                System.out.println("File too large: " + filePart.getSize() + " bytes");
                session.setAttribute("error", "File too large (max 2MB)");
                response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                return;
            }

            // Process in memory
            try (Connection con = ConnectionProvider.getCon()) {
                // Verify database connection
                if (con == null || con.isClosed()) {
                    System.out.println("Database connection failed");
                    session.setAttribute("error", "Database connection failed");
                    response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
                    return;
                }

                con.setAutoCommit(false);
                
                try (InputStream fileContent = filePart.getInputStream();
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    
                    byte[] data = new byte[16384]; // 16KB buffer
                    int nRead;
                    while ((nRead = fileContent.read(data, 0, data.length)) != -1) {
                        buffer.write(data, 0, nRead);
                    }
                    buffer.flush();
                    
                    byte[] imageData = buffer.toByteArray();
                    System.out.println("Read " + imageData.length + " bytes from file");
                    
                    try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE customers SET profile_pic_path = ? WHERE email = ?")) {
                        
                        ps.setBytes(1, imageData);
                        ps.setString(2, email);
                        
                        int rowsUpdated = ps.executeUpdate();
                        if (rowsUpdated > 0) {
                            System.out.println("Profile picture updated successfully for: " + email);
                            session.setAttribute("success", "Profile picture updated successfully!");
                        } else {
                            System.out.println("No user found for email: " + email);
                            session.setAttribute("error", "User account not found");
                        }
                        con.commit();
                    }
                } catch (SQLException e) {
                    System.out.println("Database error: " + e.getMessage());
                    if (con != null) {
                        try { 
                            con.rollback(); 
                        } catch (SQLException ex) {
                            System.out.println("Rollback failed: " + ex.getMessage());
                        }
                    }
                    session.setAttribute("error", "Database error occurred");
                } finally {
                    if (con != null) {
                        try { 
                            con.setAutoCommit(true);
                        } catch (SQLException e) { 
                            System.out.println("Error resetting auto-commit: " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Upload failed: " + e.getMessage());
            e.printStackTrace();
            session.setAttribute("error", "Upload failed: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/customer/customer-profile.jsp");
    }
}