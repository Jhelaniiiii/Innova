document.addEventListener('DOMContentLoaded', function() {
    // Navigation button functionality
    const navButtons = document.querySelectorAll('.nav-button');
    
    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            navButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
        });
    });

    // Logout button functionality
    const logoutButton = document.querySelector('.logout-button');
    
    logoutButton.addEventListener('click', () => {
        // In a real application, this would handle logout logic
        alert('Logging out...');
    });

    // Email click functionality
    const emailLinks = document.querySelectorAll('.email');
    
    emailLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // This will open the default email client
            // The href="mailto:" in HTML handles this automatically
            console.log('Opening email client for:', link.textContent);
        });
    });

    // Sort users alphabetically by name
    const usersList = document.querySelector('.users-list');
    const users = Array.from(usersList.children);
    
    function sortUsers() {
        users.sort((a, b) => {
            const nameA = a.querySelector('h2').textContent.toLowerCase();
            const nameB = b.querySelector('h2').textContent.toLowerCase();
            return nameA.localeCompare(nameB);
        });

        users.forEach(user => {
            usersList.appendChild(user);
        });
    }

    // Initial sort
    sortUsers();
});