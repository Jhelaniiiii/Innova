document.addEventListener('DOMContentLoaded', function() {
    // Navigation button functionality
    const navButtons = document.querySelectorAll('.nav-button');
    
    // Set initial active state based on current page
    const currentPath = window.location.pathname;
    navButtons.forEach(button => {
        if (button.getAttribute('href') === currentPath) {
            button.classList.add('active');
        }
        
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            navButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
        });
    });

    // Rest of your existing JavaScript remains unchanged
    const logoutButton = document.querySelector('.logout-button');
    
    logoutButton.addEventListener('click', () => {
        alert('Logging out...');
    });

    // Sort appointments by date
    const appointmentsList = document.querySelector('.appointments-list');
    if (appointmentsList) {
        const appointments = Array.from(appointmentsList.children);
        
        function sortAppointments() {
            appointments.sort((a, b) => {
                const dateA = new Date(a.querySelector('.datetime').textContent);
                const dateB = new Date(b.querySelector('.datetime').textContent);
                return dateA - dateB;
            });

            appointments.forEach(appointment => {
                appointmentsList.appendChild(appointment);
            });
        }

        sortAppointments();
    }
});