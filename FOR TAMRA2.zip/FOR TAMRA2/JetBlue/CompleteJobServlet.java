package JetBlue;
//CHANGE PACKAGE IF NEEDED
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CompleteJobServlet")
public class CompleteJobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Database configuration
    private String jdbcURL = "jdbc:mysql://localhost:3306/jetblue";
    private String dbUser = "root";
    private String dbPassword = "JhElaNi06!";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        
        try {
            String jobId = request.getParameter("jobId");

            if (jobId != null && !jobId.isEmpty()) {
                System.out.println("Completing job with ID: " + jobId);

                // Update database
                try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
                    String sql = "UPDATE jobs SET status = 'Completed', completed_at = NOW() WHERE id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(jobId));
                        int rowsAffected = pstmt.executeUpdate();
                        
                        if (rowsAffected > 0) {
                            response.getWriter().write("{\"success\":true,\"message\":\"Job completed successfully.\"}");
                        } else {
                            response.getWriter().write("{\"success\":false,\"error\":\"No job found with specified ID.\"}");
                        }
                    }
                }
            } else {
                response.getWriter().write("{\"success\":false,\"error\":\"Invalid job ID.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"success\":false,\"error\":\"" + e.getMessage().replace("\"", "\\\"") + "\"}");
        }
    }
}