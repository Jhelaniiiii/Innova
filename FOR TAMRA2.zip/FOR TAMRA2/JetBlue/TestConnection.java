package JetBlue;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class TestConnection {
    public static void main(String[] args) {
        // Get the connection
        Connection con = ConnectionProvider.getCon();
        
        if (con != null) {
            System.out.println("✅ Database connection established successfully!");
            
            // Optional: Test a simple SQL query (e.g., check MySQL version)
            try {
                String query = "SELECT VERSION()";
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(query);
                
                if (rs.next()) {
                    System.out.println("MySQL Version: " + rs.getString(1));  // Fixed: use column index 1
                }
                
                // Close resources
                rs.close();
                stmt.close();
                con.close();
            } catch (SQLException e) {
                System.err.println("❌ Query failed: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.err.println("❌ Failed to establish a database connection.");
        }
    }
}