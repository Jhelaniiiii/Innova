package JetBlue;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import java.util.Date;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import org.json.JSONArray;
import java.sql.Time;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/GetJobsServlet")
public class GetJobsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        // Get optional status filter from request
        String statusFilter = request.getParameter("status");
        
        try {
            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            try (Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/jetblue", "root", "JhElaNi06!")) {
                
                // Build SQL query with optional status filter
                String sql = "SELECT j.id, c.name as customerName, j.pickup_address as pickupAddress, "
                           + "j.delivery_address as deliveryAddress, j.pickup_info as pickupInfo, "
                           + "j.delivery_info as deliveryInfo, j.job_date as jobDate, "
                           + "j.job_time as jobTime, j.status "
                           + "FROM jobs j JOIN customers c ON j.customer_id = c.id ";
                
                if (statusFilter != null && !statusFilter.isEmpty()) {
                    sql += "WHERE j.status = ? ";
                } else {
                    sql += "WHERE j.status IN ('Pending', 'In Progress') ";
                }
                
                sql += "ORDER BY j.job_date, j.job_time";
                
                PreparedStatement stmt = conn.prepareStatement(sql);
                
                // Set parameter if status filter exists
                if (statusFilter != null && !statusFilter.isEmpty()) {
                    stmt.setString(1, statusFilter);
                }
                
                ResultSet rs = stmt.executeQuery();
                
                JSONArray jobs = new JSONArray();
                SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE d'%s' MMM, yyyy");
                SimpleDateFormat timeFormat = new SimpleDateFormat("h a");
                
                while (rs.next()) {
                    JSONObject job = new JSONObject();
                    job.put("id", rs.getInt("id"));
                    job.put("customerName", rs.getString("customerName"));
                    job.put("pickupAddress", rs.getString("pickupAddress"));
                    job.put("deliveryAddress", rs.getString("deliveryAddress"));
                    job.put("pickupInfo", rs.getString("pickupInfo"));
                    job.put("deliveryInfo", rs.getString("deliveryInfo"));
                    
                    Date date = rs.getDate("jobDate");
                    String day = String.valueOf(date.getDate());
                    String suffix = getDaySuffix(day);
                    job.put("formattedDate", String.format(dateFormat.format(date), suffix));
                    job.put("formattedTime", timeFormat.format(rs.getTime("jobTime")));
                    job.put("status", rs.getString("status"));
                    
                    jobs.put(job);
                }
                
                out.print(jobs.toString());
            }
        } catch (ClassNotFoundException e) {
            response.setStatus(500);
            out.print("{\"error\": \"Database driver not found\"}");
        } catch (SQLException e) {
            response.setStatus(500);
            out.print("{\"error\": \"Database error: " + e.getMessage().replace("\"", "'") + "\"}");
        } catch (Exception e) {
            response.setStatus(500);
            out.print("{\"error\": \"Unexpected error: " + e.getMessage().replace("\"", "'") + "\"}");
        }
    }
    
    // Helper method for date suffix
    private String getDaySuffix(String day) {
        if (day.endsWith("1") && !day.endsWith("11")) return "st";
        if (day.endsWith("2") && !day.endsWith("12")) return "nd";
        if (day.endsWith("3") && !day.endsWith("13")) return "rd";
        return "th";
    }
}