package JetBlue;
import java.sql.*;

public class ConnectionProvider {
    public static Connection getCon() {  // Renamed to match convention (e.g., "getCon")
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Use try-with-resources for auto-closing (if returning, close externally)
            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/jetblue", 
                "root", 
                "JhElaNi06!"
            );
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return null;
        }
    }
}