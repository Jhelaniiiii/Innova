document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  var mobileMenuToggle = document.getElementById("mobileMenuToggle")
  var closeSidebar = document.getElementById("closeSidebar")
  var sidebar = document.getElementById("sidebar")
  var overlay = document.getElementById("overlay")

  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", () => {
      sidebar.classList.add("active")
      overlay.classList.add("active")
    })
  }

  if (closeSidebar) {
    closeSidebar.addEventListener("click", () => {
      sidebar.classList.remove("active")
      overlay.classList.remove("active")
    })
  }

  if (overlay) {
    overlay.addEventListener("click", () => {
      sidebar.classList.remove("active")
      overlay.classList.remove("active")
    })
  }

  // Modal functionality
  var modal = document.getElementById("confirmModal")
  var modalClose = document.getElementById("modalClose")
  var confirmAction = document.getElementById("confirmAction")
  var cancelAction = document.getElementById("cancelAction")
  var modalTitle = document.getElementById("modalTitle")
  var modalMessage = document.getElementById("modalMessage")

  // Approve and Reject buttons
  var approveButton = document.querySelector(".approve-btn")
  var rejectButton = document.querySelector(".reject-btn")

  // Function to show modal
  function showModal(title, message, confirmText, action) {
    modalTitle.textContent = title
    modalMessage.textContent = message
    confirmAction.textContent = confirmText

    // Store the action function to be executed on confirm
    confirmAction.onclick = action

    modal.style.display = "flex"
  }

  // Function to hide modal
  function hideModal() {
    modal.style.display = "none"
  }

  // Close modal when clicking the close button
  if (modalClose) {
    modalClose.addEventListener("click", hideModal)
  }

  // Close modal when clicking the cancel button
  if (cancelAction) {
    cancelAction.addEventListener("click", hideModal)
  }

  // Close modal when clicking outside the modal content
  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      hideModal()
    }
  })

  // Function to handle approve action
  function approveQuote(id, name) {
    showModal(
      "Approve Quote from " + name + "?",
      "Once approved, the customer will be notified and the quote will be marked as approved.",
      "YES, APPROVE " + name.toUpperCase() + "'S QUOTE",
      () => {
        // Send AJAX request to approve the quote
        fetch("approveQuote.jsp?id=" + id, {
          method: "GET",
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              // Redirect to quotes page or reload current page
              window.location.href = "quotes.jsp"
            } else {
              alert("Error: " + data.message)
            }
          })
          .catch((error) => {
            console.error("Error:", error)
            alert("An error occurred while processing your request.")
          })
          .finally(() => {
            hideModal()
          })
      }
    )
  }

  // Function to handle reject action
  function rejectQuote(id, name) {
    showModal(
      "Reject Quote from " + name + "?",
      "Once rejected, the customer will be notified and the quote will be marked as rejected.",
      "YES, REJECT " + name.toUpperCase() + "'S QUOTE",
      () => {
        // Send AJAX request to reject the quote
        fetch("rejectQuote.jsp?id=" + id, {
          method: "GET",
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              // Redirect to quotes page or reload current page
              window.location.href = "quotes.jsp"
            } else {
              alert("Error: " + data.message)
            }
          })
          .catch((error) => {
            console.error("Error:", error)
            alert("An error occurred while processing your request.")
          })
          .finally(() => {
            hideModal()
          })
      }
    )
  }

  // Add event listener to approve button
  if (approveButton) {
    approveButton.addEventListener("click", function () {
      var id = this.getAttribute("data-id")
      var name = this.getAttribute("data-name")
      approveQuote(id, name)
    })
  }

  // Add event listener to reject button
  if (rejectButton) {
    rejectButton.addEventListener("click", function () {
      var id = this.getAttribute("data-id")
      var name = this.getAttribute("data-name")
      rejectQuote(id, name)
    })
  }

  // Enhanced Email Composer Functionality
  var emailBody = document.getElementById("emailBody")
  var emailSubject = document.getElementById("emailSubject")
  var emailTo = document.getElementById("emailTo")
  var emailCc = document.getElementById("emailCc")
  var emailBcc = document.getElementById("emailBcc")
  var currentEmailId = document.getElementById("currentEmailId")

  // Toggle fields
  var ccToggle = document.getElementById("ccToggle")
  var bccToggle = document.getElementById("bccToggle")
  var ccField = document.getElementById("ccField")
  var bccField = document.getElementById("bccField")

  // Toolbar buttons
  var formatButtons = document.querySelectorAll(".format-btn")
  var fontFamily = document.getElementById("fontFamily")
  var fontSize = document.getElementById("fontSize")
  var textColorBtn = document.getElementById("textColorBtn")
  var highlightBtn = document.getElementById("highlightBtn")
  var textColor = document.getElementById("textColor")
  var highlightColor = document.getElementById("highlightColor")

  // Action buttons
  var sendButton = document.getElementById("sendEmail")
  var sendDropdown = document.getElementById("sendDropdown")
  var sendDropdownMenu = document.getElementById("sendDropdownMenu")
  var newEmailBtn = document.getElementById("newEmail")
  var saveEmailBtn = document.getElementById("saveEmail")
  var printEmailBtn = document.getElementById("printEmail")
  var undoBtn = document.getElementById("undoBtn")
  var redoBtn = document.getElementById("redoBtn")

  // Insert buttons
  var linkBtn = document.getElementById("linkBtn")
  var imageBtn = document.getElementById("imageBtn")
  var tableBtn = document.getElementById("tableBtn")
  var attachBtn = document.getElementById("attachBtn")

  // Modals
  var linkModal = document.getElementById("linkModal")
  var tableModal = document.getElementById("tableModal")

  // File inputs
  var fileInput = document.getElementById("fileInput")
  var imageInput = document.getElementById("imageInput")

  // Attachments
  var attachmentsArea = document.getElementById("attachmentsArea")
  var attachmentsList = document.getElementById("attachmentsList")
  var attachments = []

  // Email History Elements
  var emailHistoryList = document.getElementById("emailHistoryList")
  var refreshHistoryBtn = document.getElementById("refreshHistory")

  // Current editing state
  var isEditingEmail = false
  var editingEmailId = null

  // Toggle CC field
  if (ccToggle && ccField) {
    ccToggle.addEventListener("click", () => {
      ccField.style.display = ccField.style.display === "none" ? "flex" : "none"
      ccToggle.style.backgroundColor = ccField.style.display === "flex" ? "rgba(0, 0, 0, 0.1)" : ""
    })
  }

  // Toggle BCC field
  if (bccToggle && bccField) {
    bccToggle.addEventListener("click", () => {
      bccField.style.display = bccField.style.display === "none" ? "flex" : "none"
      bccToggle.style.backgroundColor = bccField.style.display === "flex" ? "rgba(0, 0, 0, 0.1)" : ""
    })
  }

  // Format buttons functionality
  formatButtons.forEach((button) => {
    button.addEventListener("click", function () {
      var command = this.getAttribute("data-command")
      document.execCommand(command, false, null)
      updateFormatButtonStates()
      emailBody.focus()
    })
  })

  // Font family change
  if (fontFamily) {
    fontFamily.addEventListener("change", function () {
      document.execCommand("fontName", false, this.value)
      emailBody.focus()
    })
  }

  // Font size change
  if (fontSize) {
    fontSize.addEventListener("change", () => {
      document.execCommand("fontSize", false, "7")
      var fontElements = emailBody.querySelectorAll('font[size="7"]')
      fontElements.forEach((element) => {
        element.removeAttribute("size")
        element.style.fontSize = fontSize.value + "px"
      })
      emailBody.focus()
    })
  }

  // Text color
  if (textColorBtn && textColor) {
    textColorBtn.addEventListener("click", () => {
      textColor.click()
    })

    textColor.addEventListener("change", function () {
      document.execCommand("foreColor", false, this.value)
      emailBody.focus()
    })
  }

  // Highlight color
  if (highlightBtn && highlightColor) {
    highlightBtn.addEventListener("click", () => {
      highlightColor.click()
    })

    highlightColor.addEventListener("change", function () {
      document.execCommand("hiliteColor", false, this.value)
      emailBody.focus()
    })
  }

  // Undo/Redo
  if (undoBtn) {
    undoBtn.addEventListener("click", () => {
      document.execCommand("undo", false, null)
      emailBody.focus()
    })
  }

  if (redoBtn) {
    redoBtn.addEventListener("click", () => {
      document.execCommand("redo", false, null)
      emailBody.focus()
    })
  }

  // Update format button states
  function updateFormatButtonStates() {
    formatButtons.forEach((button) => {
      var command = button.getAttribute("data-command")
      if (document.queryCommandState(command)) {
        button.classList.add("active")
      } else {
        button.classList.remove("active")
      }
    })
  }

  // Update button states on selection change
  if (emailBody) {
    emailBody.addEventListener("mouseup", updateFormatButtonStates)
    emailBody.addEventListener("keyup", updateFormatButtonStates)
  }

  // Send dropdown functionality
  if (sendDropdown && sendDropdownMenu) {
    sendDropdown.addEventListener("click", (e) => {
      e.stopPropagation()
      sendDropdownMenu.classList.toggle("active")
    })

    document.addEventListener("click", () => {
      sendDropdownMenu.classList.remove("active")
    })

    sendDropdownMenu.addEventListener("click", (e) => {
      e.stopPropagation()
      var action = e.target.getAttribute("data-action")
      if (action) {
        handleSendAction(action)
        sendDropdownMenu.classList.remove("active")
      }
    })
  }

  // Handle send actions
  function handleSendAction(action) {
    var to = emailTo.value.trim()
    var cc = emailCc ? emailCc.value.trim() : ""
    var bcc = emailBcc ? emailBcc.value.trim() : ""
    var subject = emailSubject.value.trim()
    var body = emailBody.innerHTML.trim()

    if (!to && action === "send") {
      alert("Please enter a recipient email address.")
      return
    }

    switch (action) {
      case "send":
        if (!subject && !confirm("Send this message without a subject?")) {
          return
        }
        sendEmail(to, cc, bcc, subject, body)
        break
      case "schedule":
        scheduleEmail(to, cc, bcc, subject, body)
        break
      case "draft":
        saveDraft(to, cc, bcc, subject, body)
        break
    }
  }

  // Send email function with improved error handling and debugging
  function sendEmail(to, cc, bcc, subject, body) {
    console.log("Sending email with data:", { to: to, cc: cc, bcc: bcc, subject: subject, body: body })

    // Create URL with parameters instead of FormData for better debugging
    var params = new URLSearchParams()
    params.append("action", "send_email")
    params.append("id", window.quoteId)
    params.append("email_to", to)
    params.append("email_cc", cc || "")
    params.append("email_bcc", bcc || "")
    params.append("subject", subject || "")
    params.append("body", body || "")
    params.append("attachments", JSON.stringify(attachments.map((a) => ({ name: a.name, size: a.size, type: a.type }))))

    if (isEditingEmail && editingEmailId) {
      params.append("update_email_id", editingEmailId)
    }

    console.log("Request URL:", window.location.pathname + "?" + params.toString())

    fetch(window.location.pathname + "?" + params.toString(), {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    })
      .then((response) => {
        console.log("Response status:", response.status)
        console.log("Response headers:", response.headers)

        if (!response.ok) {
          throw new Error("HTTP error! status: " + response.status)
        }

        // Check if response is JSON
        var contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          return response.text().then((text) => {
            console.log("Non-JSON response:", text)
            throw new Error("Server returned non-JSON response: " + text.substring(0, 200))
          })
        }

        return response.json()
      })
      .then((data) => {
        console.log("Response data:", data)
        if (data.success) {
          // alert("Email sent successfully!")
          clearEmailForm()
          clearDraft()
          refreshEmailHistory()
        } else {
          // alert("Error: " + (data.message || "Unknown error occurred"))
        }
      })
      .catch((error) => {
        console.error("Detailed error:", error)
        console.error("Error stack:", error.stack)
        // alert("An error occurred while sending the email: " + error.message)
      })
  }

  // Schedule email function
  function scheduleEmail(to, cc, bcc, subject, body) {
    var scheduleTime = prompt("Enter schedule time (YYYY-MM-DD HH:MM):")
    if (scheduleTime) {
      console.log("Scheduling email for:", scheduleTime)
      // For now, just save as draft
      saveDraft(to, cc, bcc, subject, body)
    }
  }

  // Save draft function with improved error handling
  function saveDraft(to, cc, bcc, subject, body) {
    console.log("Saving draft with data:", { to: to, cc: cc, bcc: bcc, subject: subject, body: body })

    var params = new URLSearchParams()
    params.append("action", "save_email")
    params.append("id", window.quoteId)
    params.append("email_to", to)
    params.append("email_cc", cc || "")
    params.append("email_bcc", bcc || "")
    params.append("subject", subject || "")
    params.append("body", body || "")
    params.append("attachments", JSON.stringify(attachments.map((a) => ({ name: a.name, size: a.size, type: a.type }))))

    if (isEditingEmail && editingEmailId) {
      params.append("update_email_id", editingEmailId)
    }

    fetch(window.location.pathname + "?" + params.toString(), {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    })
      .then((response) => {
        console.log("Draft save response status:", response.status)

        if (!response.ok) {
          throw new Error("HTTP error! status: " + response.status)
        }

        var contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          return response.text().then((text) => {
            console.log("Non-JSON response:", text)
            throw new Error("Server returned non-JSON response: " + text.substring(0, 200))
          })
        }

        return response.json()
      })
      .then((data) => {
        console.log("Draft save response data:", data)
        if (data.success) {
          alert("Draft saved successfully!")
          clearDraft()
          refreshEmailHistory()
        } else {
          alert("Error: " + (data.message || "Unknown error occurred"))
        }
      })
      .catch((error) => {
        console.error("Draft save error:", error)
        alert("An error occurred while saving the draft: " + error.message)
      })
  }

  // Clear email form
  function clearEmailForm() {
    if (emailSubject) emailSubject.value = ""
    if (emailBody) emailBody.innerHTML = ""
    if (emailCc) emailCc.value = ""
    if (emailBcc) emailBcc.value = ""
    attachments = []
    updateAttachmentsList()
    isEditingEmail = false
    editingEmailId = null
    if (currentEmailId) currentEmailId.value = ""

    // Reset send button text
    if (sendButton) {
      sendButton.innerHTML = '<span class="material-icons">send</span>Send'
    }
  }

  // New email
  if (newEmailBtn) {
    newEmailBtn.addEventListener("click", () => {
      if (confirm("Start a new email? Any unsaved changes will be lost.")) {
        clearEmailForm()
        clearDraft()
      }
    })
  }

  // Save email
  if (saveEmailBtn) {
    saveEmailBtn.addEventListener("click", () => {
      var to = emailTo.value.trim()
      var cc = emailCc ? emailCc.value.trim() : ""
      var bcc = emailBcc ? emailBcc.value.trim() : ""
      var subject = emailSubject.value.trim()
      var body = emailBody.innerHTML.trim()
      saveDraft(to, cc, bcc, subject, body)
    })
  }

  // Print email
  if (printEmailBtn) {
    printEmailBtn.addEventListener("click", () => {
      var printWindow = window.open("", "_blank")
      var emailContent =
        "<html><head><title>Print Email</title></head><body>" +
        "<h3>To: " +
        emailTo.value +
        "</h3>" +
        (emailCc && emailCc.value ? "<h3>Cc: " + emailCc.value + "</h3>" : "") +
        (emailBcc && emailBcc.value ? "<h3>Bcc: " + emailBcc.value + "</h3>" : "") +
        "<h3>Subject: " +
        emailSubject.value +
        "</h3>" +
        "<hr>" +
        "<div>" +
        emailBody.innerHTML +
        "</div>" +
        "</body></html>"
      printWindow.document.write(emailContent)
      printWindow.document.close()
      printWindow.print()
    })
  }

  // Link insertion
  if (linkBtn) {
    linkBtn.addEventListener("click", () => {
      linkModal.style.display = "flex"
    })
  }

  // Link modal functionality
  var linkModalClose = document.getElementById("linkModalClose")
  var insertLink = document.getElementById("insertLink")
  var cancelLink = document.getElementById("cancelLink")
  var linkText = document.getElementById("linkText")
  var linkUrl = document.getElementById("linkUrl")

  if (linkModalClose) {
    linkModalClose.addEventListener("click", () => {
      linkModal.style.display = "none"
    })
  }

  if (cancelLink) {
    cancelLink.addEventListener("click", () => {
      linkModal.style.display = "none"
    })
  }

  if (insertLink) {
    insertLink.addEventListener("click", () => {
      var text = linkText.value.trim()
      var url = linkUrl.value.trim()

      if (text && url) {
        var linkHtml = '<a href="' + url + '" target="_blank">' + text + "</a>"
        document.execCommand("insertHTML", false, linkHtml)
        linkText.value = ""
        linkUrl.value = ""
        linkModal.style.display = "none"
        emailBody.focus()
      } else {
        alert("Please enter both link text and URL.")
      }
    })
  }

  // Table insertion
  if (tableBtn) {
    tableBtn.addEventListener("click", () => {
      tableModal.style.display = "flex"
    })
  }

  // Table modal functionality
  var tableModalClose = document.getElementById("tableModalClose")
  var insertTable = document.getElementById("insertTable")
  var cancelTable = document.getElementById("cancelTable")
  var tableRows = document.getElementById("tableRows")
  var tableCols = document.getElementById("tableCols")

  if (tableModalClose) {
    tableModalClose.addEventListener("click", () => {
      tableModal.style.display = "none"
    })
  }

  if (cancelTable) {
    cancelTable.addEventListener("click", () => {
      tableModal.style.display = "none"
    })
  }

  if (insertTable) {
    insertTable.addEventListener("click", () => {
      var rows = Number.parseInt(tableRows.value)
      var cols = Number.parseInt(tableCols.value)

      if (rows > 0 && cols > 0) {
        var tableHtml = '<table border="1" style="border-collapse: collapse; width: 100%;">'

        for (var i = 0; i < rows; i++) {
          tableHtml += "<tr>"
          for (var j = 0; j < cols; j++) {
            tableHtml += '<td style="padding: 8px; border: 1px solid #ddd;">&nbsp;</td>'
          }
          tableHtml += "</tr>"
        }

        tableHtml += "</table><br>"
        document.execCommand("insertHTML", false, tableHtml)
        tableModal.style.display = "none"
        emailBody.focus()
      }
    })
  }

  // Image insertion
  if (imageBtn && imageInput) {
    imageBtn.addEventListener("click", () => {
      imageInput.click()
    })

    imageInput.addEventListener("change", (e) => {
      var file = e.target.files[0]
      if (file && file.type.startsWith("image/")) {
        var reader = new FileReader()
        reader.onload = (e) => {
          var imgHtml =
            '<img src="' + e.target.result + '" style="max-width: 100%; height: auto;" alt="Inserted image">'
          document.execCommand("insertHTML", false, imgHtml)
          emailBody.focus()
        }
        reader.readAsDataURL(file)
      }
    })
  }

  // File attachments
  if (attachBtn && fileInput) {
    attachBtn.addEventListener("click", () => {
      fileInput.click()
    })

    fileInput.addEventListener("change", (e) => {
      var files = Array.from(e.target.files)
      files.forEach((file) => {
        attachments.push({
          name: file.name,
          size: file.size,
          type: file.type,
          file: file,
        })
      })
      updateAttachmentsList()
      e.target.value = "" // Reset input
    })
  }

  // Update attachments list
  function updateAttachmentsList() {
    if (!attachmentsList) return

    if (attachments.length === 0) {
      attachmentsArea.style.display = "none"
      return
    }

    attachmentsArea.style.display = "block"
    attachmentsList.innerHTML = ""

    attachments.forEach((attachment, index) => {
      var attachmentItem = document.createElement("div")
      attachmentItem.className = "attachment-item"
      attachmentItem.innerHTML =
        '<span class="material-icons">attach_file</span>' +
        "<span>" +
        attachment.name +
        " (" +
        formatFileSize(attachment.size) +
        ")</span>" +
        '<button type="button" class="attachment-remove" data-index="' +
        index +
        '">' +
        '<span class="material-icons">close</span>' +
        "</button>"
      attachmentsList.appendChild(attachmentItem)
    })

    // Add remove functionality
    attachmentsList.querySelectorAll(".attachment-remove").forEach((btn) => {
      btn.addEventListener("click", function () {
        var index = Number.parseInt(this.getAttribute("data-index"))
        attachments.splice(index, 1)
        updateAttachmentsList()
      })
    })
  }

  // Format file size
  function formatFileSize(bytes) {
    if (bytes === 0) return "0 Bytes"
    var k = 1024
    var sizes = ["Bytes", "KB", "MB", "GB"]
    var i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Send button functionality
  if (sendButton) {
    sendButton.addEventListener("click", () => {
      handleSendAction("send")
    })
  }

  // Full screen functionality
  var fullScreenBtn = document.getElementById("fullScreenBtn")
  if (fullScreenBtn) {
    fullScreenBtn.addEventListener("click", () => {
      var emailWrapper = document.querySelector(".email-wrapper")
      if (emailWrapper.requestFullscreen) {
        emailWrapper.requestFullscreen()
      } else if (emailWrapper.webkitRequestFullscreen) {
        emailWrapper.webkitRequestFullscreen()
      } else if (emailWrapper.msRequestFullscreen) {
        emailWrapper.msRequestFullscreen()
      }
    })
  }

  // Spell check functionality
  var spellCheckBtn = document.getElementById("spellCheckBtn")
  if (spellCheckBtn) {
    spellCheckBtn.addEventListener("click", () => {
      emailBody.spellcheck = !emailBody.spellcheck
      spellCheckBtn.classList.toggle("active")
      alert("Spell check " + (emailBody.spellcheck ? "enabled" : "disabled"))
    })
  }

  // Email History Functionality
  function refreshEmailHistory() {
    var currentUrl = new URL(window.location.href)
    currentUrl.searchParams.set("refresh", "true")

    fetch(currentUrl.toString())
      .then((response) => response.text())
      .then((html) => {
        // Parse the response and update only the email history section
        var parser = new DOMParser()
        var doc = parser.parseFromString(html, "text/html")
        var newHistoryList = doc.getElementById("emailHistoryList")

        if (newHistoryList && emailHistoryList) {
          emailHistoryList.innerHTML = newHistoryList.innerHTML
          attachEmailHistoryEvents()
        }
      })
      .catch((error) => {
        console.error("Error refreshing history:", error)
      })
  }

  // Attach events to email history items
  function attachEmailHistoryEvents() {
    // Edit email buttons
    document.querySelectorAll(".edit-email-btn").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.stopPropagation()
        var emailId = this.getAttribute("data-email-id")
        editEmail(emailId)
      })
    })

    // Delete email buttons
    document.querySelectorAll(".delete-email-btn").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.stopPropagation()
        var emailId = this.getAttribute("data-email-id")
        deleteEmail(emailId)
      })
    })

    // Email history item click (for viewing)
    document.querySelectorAll(".email-history-item").forEach((item) => {
      item.addEventListener("click", function () {
        var emailId = this.getAttribute("data-email-id")
        viewEmail(emailId)
      })
    })
  }

/* 
  // Edit email function - FIXED
  function editEmail(emailId) {
    console.log("Editing email with ID:", emailId)

    var currentUrl = new URL(window.location.href)
    currentUrl.searchParams.set("action", "get_email")
    currentUrl.searchParams.set("emailId", emailId)

    fetch(currentUrl.toString())
      .then((response) => {
        console.log("Edit email response status:", response.status)

        if (!response.ok) {
          throw new Error("HTTP error! status: " + response.status)
        }

        var contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          return response.text().then((text) => {
            console.log("Non-JSON response:", text)
            throw new Error("Server returned non-JSON response")
          })
        }

        return response.json()
      })
      .then((data) => {
        console.log("Edit email response data:", data)

        if (data.success && data.email) {
          var email = data.email

          // Populate form with email data
          if (emailTo) emailTo.value = email.to || ""
          if (emailSubject) emailSubject.value = email.subject || ""
          if (emailBody) emailBody.innerHTML = email.body || ""

          if (email.cc && emailCc) {
            emailCc.value = email.cc
            if (ccField) {
              ccField.style.display = "flex"
              if (ccToggle) ccToggle.style.backgroundColor = "rgba(0, 0, 0, 0.1)"
            }
          }

          if (email.bcc && emailBcc) {
            emailBcc.value = email.bcc
            if (bccField) {
              bccField.style.display = "flex"
              if (bccToggle) bccToggle.style.backgroundColor = "rgba(0, 0, 0, 0.1)"
            }
          }

          // Set editing state
          isEditingEmail = true
          editingEmailId = emailId
          if (currentEmailId) currentEmailId.value = emailId

          // Update send button text
          if (sendButton) {
            sendButton.innerHTML = '<span class="material-icons">update</span>Update'
          }

          // Scroll to email composer
          var emailWrapper = document.querySelector(".email-wrapper")
          if (emailWrapper) {
            emailWrapper.scrollIntoView({ behavior: "smooth" })
          }

          console.log("Email loaded successfully for editing")
        } else {
          alert("Error: " + (data.message || "Failed to load email"))
        }
      })
      .catch((error) => {
        // console.error("Error loading email for editing:", error)
        // alert("An error occurred while loading the email: " + error.message)
      })
  }
*/
  // Delete email function
  function deleteEmail(emailId) {
    showModal(
      "Delete Email?",
      "Are you sure you want to delete this email? This action cannot be undone.",
      "YES, DELETE EMAIL",
      () => {
        var currentUrl = new URL(window.location.href)
        currentUrl.searchParams.set("action", "delete_email")
        currentUrl.searchParams.set("emailId", emailId)

        fetch(currentUrl.toString())
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              alert("Email deleted successfully!")
              refreshEmailHistory()

              // If we're editing this email, clear the form
              if (editingEmailId === emailId) {
                clearEmailForm()
              }
            } else {
              alert("Error: " + data.message)
            }//
          })
          .catch((error) => {
            console.error("Error:", error)
            //alert("")
          })
          .finally(() => {
            hideModal()
          })
      }
    )
  }

  /* View email function (for read-only viewing)
  function viewEmail(emailId) {
    var currentUrl = new URL(window.location.href)
    currentUrl.searchParams.set("action", "get_email")
    currentUrl.searchParams.set("emailId", emailId)

    fetch(currentUrl.toString())
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          var email = data.email

          // Create a modal to display email content
          var viewModal = document.createElement("div")
          viewModal.className = "modal-container"
          viewModal.style.display = "flex"
          viewModal.innerHTML =
            '<div class="modal-content" style="max-width: 600px; text-align: left;">' +
            '<button class="modal-close" onclick="this.closest(\'.modal-container\').remove()">&times;</button>' +
            "<h2>Email Details</h2>" +
            '<div style="margin: 20px 0;">' +
            '<strong>Status:</strong> <span class="email-status-badge ' +
            email.status +
            '">' +
            email.status.toUpperCase() +
            "</span>" +
            "</div>" +
            '<div style="margin: 10px 0;"><strong>To:</strong> ' +
            email.to +
            "</div>" +
            (email.cc ? '<div style="margin: 10px 0;"><strong>Cc:</strong> ' + email.cc + "</div>" : "") +
            (email.bcc ? '<div style="margin: 10px 0;"><strong>Bcc:</strong> ' + email.bcc + "</div>" : "") +
            '<div style="margin: 10px 0;"><strong>Subject:</strong> ' +
            (email.subject || "(No Subject)") +
            "</div>" +
            '<div style="margin: 20px 0; padding: 15px; border: 1px solid #e0e0e0; border-radius: 4px; background: #f9f9f9;">' +
            (email.body || "(No content)") +
            "</div>" +
            '<div class="modal-actions">' +
            '<button onclick="this.closest(\'.modal-container\').remove()" class="cancel-button">Close</button>' +
            "</div>" +
            "</div>"

          document.body.appendChild(viewModal)

          // Close modal when clicking outside
          viewModal.addEventListener("click", (e) => {
            if (e.target === viewModal) {
              viewModal.remove()
            }
          })
        } else {
          alert("Error: " + data.message)
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("An error occurred while loading the email.")
      })
  }

*/
  // Refresh history button
  if (refreshHistoryBtn) {
    refreshHistoryBtn.addEventListener("click", () => {
      refreshEmailHistory()
    })
  }

  // Auto-save functionality with improved logic
  var autoSaveInterval
  function startAutoSave() {
    autoSaveInterval = setInterval(() => {
      // Only auto-save if we're not editing an existing email and there's content
      if (!isEditingEmail) {
        var to = emailTo ? emailTo.value.trim() : ""
        var subject = emailSubject ? emailSubject.value.trim() : ""
        var body = emailBody ? emailBody.innerHTML.trim() : ""

        // Only save if there's meaningful content
        if (to || subject || (body && body !== "")) {
          console.log("Auto-saving draft...")
          var draftData = {
            to: to,
            cc: emailCc ? emailCc.value.trim() : "",
            bcc: emailBcc ? emailBcc.value.trim() : "",
            subject: subject,
            body: body,
            timestamp: new Date().toISOString(),
            quoteId: window.quoteId,
          }
          localStorage.setItem("emailDraft_" + window.quoteId, JSON.stringify(draftData))
        }
      }
    }, 30000) // Auto-save every 30 seconds
  }

  // Load draft on page load with improved logic
  function loadDraft() {
    // Only load draft if we're not editing an existing email
    if (!isEditingEmail) {
      var draft = localStorage.getItem("emailDraft_" + window.quoteId)
      if (draft) {
        try {
          var draftData = JSON.parse(draft)
          // Check if draft is for current quote and not too old (24 hours)
          var draftAge = new Date() - new Date(draftData.timestamp)
          var maxAge = 24 * 60 * 60 * 1000 // 24 hours in milliseconds

          if (draftData.quoteId === window.quoteId && draftAge < maxAge) {
            // Only show prompt if there's meaningful content
            if (draftData.to || draftData.subject || (draftData.body && draftData.body !== "")) {
              if (confirm("A draft email was found. Would you like to restore it?")) {
                if (emailTo) emailTo.value = draftData.to || ""
                if (emailCc) emailCc.value = draftData.cc || ""
                if (emailBcc) emailBcc.value = draftData.bcc || ""
                if (emailSubject) emailSubject.value = draftData.subject || ""
                if (emailBody) emailBody.innerHTML = draftData.body || ""
              } else {
                // If user declines, clear the old draft
                clearDraft()
              }
            }
          } else {
            // Clear old or invalid drafts
            clearDraft()
          }
        } catch (e) {
          console.error("Error loading draft:", e)
          clearDraft()
        }
      }
    }
  }

  // Clear draft when email is sent or saved
  function clearDraft() {
    localStorage.removeItem("emailDraft_" + window.quoteId)
  }

  // Keyboard shortcuts
  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case "b":
          e.preventDefault()
          document.execCommand("bold", false, null)
          updateFormatButtonStates()
          break
        case "i":
          e.preventDefault()
          document.execCommand("italic", false, null)
          updateFormatButtonStates()
          break
        case "u":
          e.preventDefault()
          document.execCommand("underline", false, null)
          updateFormatButtonStates()
          break
        case "s":
          e.preventDefault()
          if (saveEmailBtn) saveEmailBtn.click()
          break
        case "Enter":
          if (e.shiftKey) {
            e.preventDefault()
            if (sendButton) sendButton.click()
          }
          break
      }
    }
  })

  // Initialize
  attachEmailHistoryEvents()
  startAutoSave()

  // Load draft after a short delay to ensure all elements are ready
  setTimeout(() => {
    loadDraft()
  }, 500)
})
