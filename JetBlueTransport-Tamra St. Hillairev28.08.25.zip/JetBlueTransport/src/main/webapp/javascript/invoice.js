document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
    
    // Load required libraries
    function loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
            document.head.appendChild(script);
        });
    }

    Promise.all([
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'),
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js')
    ])
    .then(() => {
        console.log('All libraries loaded successfully');
        initializeInvoiceFunctionality();
    })
    .catch(error => {
        console.error('Error loading libraries:', error);
        alert('Failed to load required PDF libraries. Please try again.');
    });

    function initializeInvoiceFunctionality() {
        console.log('Initializing invoice functionality');
        
        if (!window.jspdf) {
            console.error('jsPDF not loaded correctly');
            return;
        }

        const { jsPDF } = window.jspdf;
        
        // Helper function to get elements safely
        const getElement = (selector, required = true) => {
            const el = document.querySelector(selector);
            if (!el && required) {
                console.error(`Element not found: ${selector}`);
                throw new Error(`Required element missing: ${selector}`);
            }
            return el;
        };
        
        try {
            // Initialize date with current date
            const today = new Date().toISOString().split('T')[0];
            const dateInput = getElement('#invoiceDate');
            if (dateInput) dateInput.value = today;

            // Get all necessary elements
            const addNewBtn1 = getElement('.add-new-btn');
            const addNewBtn2 = getElement('.add-new-btn2');
            const packingTable = getElement('#itemsTable');
            const laborTable = getElement('#itemsTable2');
            const transportTable = getElement('#itemsTable3');
            const saveBtn = getElement('.save-btn');
            const downPaymentInput = getElement('#dPay');

            // Add event listeners for calculations
            if (downPaymentInput) {
                downPaymentInput.addEventListener('input', updateTotal);
            }

            // Add new item functionality for packing materials
            if (addNewBtn1 && packingTable) {
                addNewBtn1.addEventListener('click', function() {
                    const rowCount = packingTable.querySelectorAll('tr').length + 1;
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td><input type="text" placeholder="Item description"></td>
                        <td><input type="number" class="qty" value="1" min="0"></td>
                        <td><input type="number" class="unPrice" value="0.00" min="0" step="0.01"></td>
                        <td class="subtotal">$0.00</td>
                        <td><button class="remove-row">Remove</button></td>
                    `;
                    packingTable.appendChild(newRow);
                    updateTotal();
                });
            }

            // Add new item functionality for labor
            if (addNewBtn2 && laborTable) {
                addNewBtn2.addEventListener('click', function() {
                    const rowCount = laborTable.querySelectorAll('tr').length + 1;
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td><input type="text" placeholder="Labor description"></td>
                        <td><input type="number" class="days" value="1" min="0"></td>
                        <td><input type="number" class="qty" value="1" min="0"></td>
                        <td><input type="number" class="unPrice" value="0.00" min="0" step="0.01"></td>
                        <td class="subtotal">$0.00</td>
                        <td><button class="remove-row">Remove</button></td>
                    `;
                    laborTable.appendChild(newRow);
                    updateTotal();
                });
            }

            // Remove row functionality for both tables
            function setupRemoveRowHandler(table) {
                if (!table) return;
                
                table.addEventListener('click', function(event) {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('tr');
                        if (row) {
                            row.remove();
                            updateTotal();
                        }
                    }
                });
            }

            setupRemoveRowHandler(packingTable);
            setupRemoveRowHandler(laborTable);

            // Calculate subtotals and totals
            function setupTableCalculations(table) {
                if (!table) return;
                
                table.addEventListener('input', function(event) {
                    const target = event.target;
                    if (target.classList.contains('qty') || 
                        target.classList.contains('unPrice') || 
                        target.classList.contains('days')) {
                        calculateRowTotal(target.closest('tr'));
                        updateTotal();
                    }
                });
            }

            function calculateRowTotal(row) {
                if (!row) return;
                
                const qtyInput = row.querySelector('.qty');
                const priceInput = row.querySelector('.unPrice');
                const daysInput = row.querySelector('.days');
                const subtotalCell = row.querySelector('.subtotal');
                
                if (!qtyInput || !priceInput || !subtotalCell) return;
                
                const qty = parseFloat(qtyInput.value) || 0;
                const price = parseFloat(priceInput.value) || 0;
                const days = daysInput ? (parseFloat(daysInput.value) || 1) : 1;
                
                const subtotal = qty * price * days;
                subtotalCell.textContent = `$${subtotal.toFixed(2)}`;
            }

            // Initialize calculations for all existing rows
            function initializeRowCalculations() {
                document.querySelectorAll('#itemsTable tr, #itemsTable2 tr, #itemsTable3 tr').forEach(row => {
                    calculateRowTotal(row);
                });
                updateTotal();
            }

            setupTableCalculations(packingTable);
            setupTableCalculations(laborTable);
            setupTableCalculations(transportTable);

            function updateTotal() {
                // Calculate subtotal from all items
                const subtotals = Array.from(document.querySelectorAll('.subtotal'))
                    .map(el => parseFloat(el.textContent.replace('$', '')) || 0);
                const subtotal = subtotals.reduce((sum, value) => sum + value, 0);
                
                // Update subtotal display
                const subtotalElement = document.getElementById('subtotalAmount');
                if (subtotalElement) {
                    subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
                }
                
                // Calculate total after downpayment
                const downPayment = parseFloat(downPaymentInput?.value) || 0;
                const total = Math.max(0, subtotal - downPayment);
                
                // Update total display
                const totalElement = document.getElementById('totalAmount');
                if (totalElement) {
                    totalElement.textContent = `$${total.toFixed(2)}`;
                }
            }

            // Save button event listener
            if (saveBtn) {
                saveBtn.addEventListener('click', function() {
                    console.log('Generate PDF button clicked');
                    generatePDF();
                });
            }

            // PDF Generation Function
            function generatePDF() {
                try {
                    const doc = new jsPDF();
                    let currentY = 20;
                    const pageHeight = doc.internal.pageSize.height;
                    const margin = 15;
                    const pageWidth = doc.internal.pageSize.getWidth();

                    function addNewPageIfNeeded(spaceNeeded) {
                        if (currentY + spaceNeeded > pageHeight - margin) {
                            doc.addPage();
                            currentY = margin;
                            // Add header on new pages
                            doc.setFontSize(10);
                            doc.setTextColor(112, 112, 112);
                            doc.text(`Jet Blue Transport Service - Page ${doc.internal.getNumberOfPages()}`, margin, currentY);
                            currentY += 10;
                        }
                    }

                    // Try to load logo
                    const logo = new Image();
                    logo.crossOrigin = "Anonymous";
                    
                    const logoPaths = [
                        '../Images/Jet_Blue_LOGO.jpg',
                        './Images/Jet_Blue_LOGO.jpg',
                        'Images/Jet_Blue_LOGO.jpg'
                    ];
                    
                    let logoLoaded = false;
                    
                    const tryNextLogo = (attempt = 0) => {
                        if (attempt < logoPaths.length) {
                            logo.src = logoPaths[attempt];
                            logo.onload = function() {
                                logoLoaded = true;
                                addLogoToPDF();
                            };
                            logo.onerror = function() {
                                tryNextLogo(attempt + 1);
                            };
                        } else {
                            console.log("All logo attempts failed, proceeding without logo");
                            generatePDFContent();
                        }
                    };
                    
                    function addLogoToPDF() {
                        try {
                            addNewPageIfNeeded(30);
                            doc.addImage(logo, 'JPEG', margin, currentY, 35, 30);
                            currentY += 9;
                            generatePDFContent();
                        } catch (e) {
                            console.error("Error adding logo:", e);
                            generatePDFContent();
                        }
                    }
                    
                    tryNextLogo();

                    function generatePDFContent() {
                        try {
                            // Header section
                            addNewPageIfNeeded(50);
                            doc.setFontSize(18);
                            doc.setFont("helvetica", "bold");
                            doc.setTextColor(5, 0, 154);
                            doc.text('Jet Blue Transport Service', logoLoaded ? 50 : margin, currentY);
                            currentY += 10;
                            
                            // Company address
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.setTextColor(112, 112, 112);
                            doc.text('16 Fatima Trace, Paramin, Maraval 121007', logoLoaded ? 50 : margin, currentY);
                            currentY += 5;
                            doc.text('Tel. No.: 721-2443 / 393-6449', logoLoaded ? 50 : margin, currentY);
                            currentY += 15;

                            // Invoice details
                            doc.setFontSize(12);
                            const invoiceNo = `Invoice No.: ${document.getElementById('invoiceNumber')?.value || '00001'}`;
                            const invoiceDate = `Invoice Date: ${document.getElementById('invoiceDate')?.value || today}`;
                            doc.text(invoiceNo, pageWidth - margin - doc.getTextWidth(invoiceNo), currentY - 15);
                            doc.text(invoiceDate, pageWidth - margin - doc.getTextWidth(invoiceDate), currentY - 8);

                            // Horizontal line
                            doc.setDrawColor(221, 221, 221);
                            doc.line(margin, currentY, pageWidth - margin, currentY);
                            currentY += 10;

                            // Client information
                            addNewPageIfNeeded(40);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Client Information:', margin, currentY);
                            currentY += 7;
                            doc.setFont("helvetica", "normal");
                            
                            const clientInfo = [
                                `Name: ${document.getElementById('clientName')?.value || ''}`,
                                `Phone: ${document.getElementById('clientNumber')?.value || ''}`,
                                `Email: ${document.getElementById('clientEmail')?.value || ''}`,
                                `Address: ${document.getElementById('clientAddress')?.value || ''}`
                            ];
                            
                            clientInfo.forEach((info, i) => {
                                doc.text(info, margin, currentY + (i * 7));
                            });
                            currentY += 28;

                            // From/To addresses
                            addNewPageIfNeeded(50);
                            doc.setFillColor(202, 217, 255);
                            doc.roundedRect(margin, currentY, (pageWidth/2) - margin - 5, 40, 3, 3, 'F');
                            doc.roundedRect((pageWidth/2) + 5, currentY, (pageWidth/2) - margin - 5, 40, 3, 3, 'F');
                            
                            doc.setFontSize(12);
                            doc.text('From:', margin + 5, currentY + 8);
                            const fromContent = document.querySelector('.from-address .address-content');
                            if (fromContent) {
                                const fromLines = Array.from(fromContent.children).map(el => el.textContent.trim());
                                fromLines.forEach((line, i) => doc.text(line, margin + 10, currentY + 15 + (i * 7)));
                            }
                            
                            doc.text('To:', (pageWidth/2) + 10, currentY + 8);
                            const toContent = document.querySelector('.to-address .address-content');
                            if (toContent) {
                                const toLines = Array.from(toContent.children).map(el => el.textContent.trim());
                                toLines.forEach((line, i) => doc.text(line, (pageWidth/2) + 15, currentY + 15 + (i * 7)));
                            }
                            currentY += 50;

                            // ===== PACKING MATERIALS SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Packing and Wrapping materials', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(Estimated amounts - any additional material required will be purchased at clients cost)', margin, currentY);
                            currentY += 10;
                            
                            // Collect packing data
                            const packingData = [['Description', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const packingRows = document.querySelectorAll('#itemsTable tr');
                            
                            packingRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && qtyInput && priceInput && subtotalCell) {
                                    packingData.push([
                                        descInput.value || '',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [packingData[0]],
                                body: packingData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 'auto' },
                                    1: { cellWidth: 25, halign: 'center' },
                                    2: { cellWidth: 35, halign: 'right' },
                                    3: { cellWidth: 35, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 10;

                            // ===== LABOUR SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Labour', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(Packing, wrapping, dismantling households items/ loading on truck)', margin, currentY);
                            currentY += 10;
                            
                            // Collect labour data
                            const labourData = [['Description', 'Days', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const labourRows = document.querySelectorAll('#itemsTable2 tr');
                            
                            labourRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const daysInput = row.querySelector('.days');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && daysInput && qtyInput && priceInput && subtotalCell) {
                                    labourData.push([
                                        descInput.value || '',
                                        daysInput.value || '0',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [labourData[0]],
                                body: labourData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 'auto' },
                                    1: { cellWidth: 20, halign: 'center' },
                                    2: { cellWidth: 25, halign: 'center' },
                                    3: { cellWidth: 30, halign: 'right' },
                                    4: { cellWidth: 30, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 10;

                            // ===== TRANSPORT SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Transport', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(Estimated amount of trips - any additional trips required will be at clients cost)', margin, currentY);
                            currentY += 10;
                            
                            // Collect transport data
                            const transportData = [['Description', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const transportRows = document.querySelectorAll('#itemsTable3 tr');
                            
                            transportRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && qtyInput && priceInput && subtotalCell) {
                                    transportData.push([
                                        descInput.value || '',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [transportData[0]],
                                body: transportData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 'auto' },
                                    1: { cellWidth: 25, halign: 'center' },
                                    2: { cellWidth: 35, halign: 'right' },
                                    3: { cellWidth: 35, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 15;

                            // Payment Options
                            addNewPageIfNeeded(30);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Payment Options', margin, currentY);
                            currentY += 7;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");

                            const paymentOptions = [
                                '1. Cash On Delivery',
                                '2. Credit JMMB Bank Account No.:007600014296'
                            ];

                            paymentOptions.forEach((option, index) => {
                                if (currentY > pageHeight - 20) {
                                    doc.addPage();
                                    currentY = margin;
                                }
                                doc.text(option, margin + 5, currentY);
                                currentY += 7;
                            });
                        
                            currentY += 10;

                            handleSignature();

                function handleSignature() {
                    const signature = new Image();
                    signature.crossOrigin = "Anonymous";

                    const signaturePaths = [
                        '../Images/Signature.png',
                        './Images/Signature.png',
                        'Images/Signature.png'
                    ];

                    let signatureLoaded = false;

                    const tryNextSignature = (attempt = 0) => {
                        if (attempt < signaturePaths.length) {
                            signature.src = signaturePaths[attempt];
                            signature.onload = function() {
                                signatureLoaded = true;
                                try {
                                    addNewPageIfNeeded(40);
                                    doc.addImage(signature, 'PNG', margin, currentY, 60, 20);
                                    addTotalAmount();
                                } catch (e) {
                                    console.error("Error adding signature:", e);
                                    tryNextSignature(attempt + 1);
                                }
                            };
                            signature.onerror = function() {
                                tryNextSignature(attempt + 1);
                            };
                        } else {
                            console.log("All signature attempts failed, proceeding without signature");
                            // Add space where signature would be
                            currentY += 30;
                            addTotalAmount();
                        }
                    };

                    tryNextSignature();
                }

                function addTotalAmount() {
                    // Ensure we have space for the totals section
                    addNewPageIfNeeded(40);
                    
                    // Total amount section
                    doc.setFillColor(202, 217, 255);
                    doc.roundedRect(pageWidth - 100, currentY, 85, 25, 3, 3, 'F');
                    
                    doc.setFontSize(12);
                    doc.setTextColor(112, 112, 112);
                    doc.text('Subtotal:', pageWidth - 95, currentY + 8);
                    doc.text('Less Downpayment:', pageWidth - 95, currentY + 16);
                    doc.text('Total:', pageWidth - 95, currentY + 24);
                    
                    doc.setFontSize(12);
                    doc.setFont("helvetica", "bold");
                    doc.setTextColor(5, 0, 154);
                    const subtotalAmount = document.getElementById('subtotalAmount')?.textContent || '$0.00';
                    doc.text(subtotalAmount, pageWidth - 20, currentY + 8, { align: 'right' });
                    
                    const downPayment = document.getElementById('dPay')?.value || '0.00';
                    doc.text(`-$${parseFloat(downPayment).toFixed(2)}`, pageWidth - 20, currentY + 16, { align: 'right' });
                    
                    const totalAmount = document.getElementById('totalAmount')?.textContent || '$0.00';
                    doc.text(totalAmount, pageWidth - 20, currentY + 24, { align: 'right' });
                    
                    // Save the PDF after totals are added
                    const invoiceNumber = document.getElementById('invoiceNumber')?.value || 'JB-INV-0001';
                    doc.save(`JetBlue_Invoice_${invoiceNumber}.pdf`);
                    console.log('PDF saved successfully');
                }
                        } catch (contentError) {
                            console.error('Error generating PDF content:', contentError);
                            alert('Error generating PDF content. Please check console for details.');
                        }
                    }
                } catch (pdfError) {
                    console.error('Error creating PDF:', pdfError);
                    alert('Failed to create PDF. Please check console for details.');
                }
            }

            // Initialize all calculations
            initializeRowCalculations();
            console.log('Invoice functionality initialized successfully');
        } catch (initError) {
            console.error('Error initializing invoice functionality:', initError);
            alert('Failed to initialize invoice functionality. Please check console for details.');
        }
    }
});