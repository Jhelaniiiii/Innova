package JetBlue;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/admin/AddJobServlet")
public class AddJobServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String customerName = request.getParameter("name");
        String fromCity = request.getParameter("fromCity");
        String fromStreet = request.getParameter("fromStreet");
        String toCity = request.getParameter("toCity");
        String toStreet = request.getParameter("toStreet");
        String spec1 = request.getParameter("spec1");
        String spec2 = request.getParameter("spec2");
        String jobDate = request.getParameter("date");
        String jobTime = request.getParameter("time");
        String status = request.getParameter("status");
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/jetblue", "root", "JapanStar3s3!")) {
            String customerSql = "SELECT id FROM customers WHERE name = ?";
            PreparedStatement custStmt = conn.prepareStatement(customerSql);
            custStmt.setString(1, customerName);
            ResultSet rs = custStmt.executeQuery();

            if (rs.next()) {
                int customerId = rs.getInt("id");

                String insertSql = "INSERT INTO jobs (customer_id, pickup_address, delivery_address, pickup_info, delivery_info, job_date, job_time, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(insertSql);
                stmt.setInt(1, customerId);
                stmt.setString(2, fromCity + ", " + fromStreet);
                stmt.setString(3, toCity + ", " + toStreet);
                stmt.setString(4, spec1);
                stmt.setString(5, spec2);
                stmt.setString(6, jobDate);
                stmt.setString(7, jobTime);
                stmt.setString(8, status);
                int result = stmt.executeUpdate();
                out.print("{\"success\": " + (result > 0) + "}");
            } else {
                out.print("{\"success\": false, \"error\": \"Customer not found\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"error\": \"" + e.getMessage().replace("\"", "'") + "\"}");
        }
    }
}

