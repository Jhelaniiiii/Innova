import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailService {
    private final String username;
    private final String password;
    private final Properties props;

    public EmailService(String host, int port, String username, String password, boolean ssl) {
        this.username = username;
        this.password = password;
        
        props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", String.valueOf(ssl));
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);
    }

    public void sendEmail(String to, String cc, String bcc, String subject, String body) throws MessagingException {
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        
        if (cc != null && !cc.trim().isEmpty()) {
            message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
        }
        
        if (bcc != null && !bcc.trim().isEmpty()) {
            message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bcc));
        }
        
        message.setSubject(subject);
        message.setContent(body, "text/html; charset=utf-8");
        
        Transport.send(message);
    }
}