document.addEventListener("DOMContentLoaded", function() {
  console.log('Quotes page initialized');
  
  // ===== DOM ELEMENTS =====
  // Core elements
  const sidebar = document.getElementById("sidebar");
  const mobileMenuToggle = document.getElementById("mobileMenuToggle");
  const closeSidebar = document.getElementById("closeSidebar");
  const overlay = document.getElementById("overlay");
  const contentWrapper = document.querySelector(".content-wrapper");
  const quotesList = document.getElementById("quotesList");
  
  // Search elements
  const searchBar = document.querySelector(".search-bar-search");
  const searchInput = document.getElementById("searchInput");
  
  // Pagination elements
  const paginationContainer = document.getElementById("pagination");
  const noResultsMessage = document.getElementById("noResults");
  
  // Modal elements
  const confirmModal = document.getElementById("confirmModal");
  const modalTitle = document.getElementById("modalTitle");
  const modalMessage = document.getElementById("modalMessage");
  const confirmAction = document.getElementById("confirmAction");
  const cancelAction = document.getElementById("cancelAction");
  const modalClose = document.getElementById("modalClose");
  
  // Card menu dropdown
  const cardMenuDropdown = document.getElementById("cardMenuDropdown");
  
  // Check if quotes list exists
  if (!quotesList) {
    console.error('Quotes list not found');
    return;
  }
  
  // Get all quote cards
  const quotes = Array.from(quotesList.querySelectorAll(".quote-card"));
  console.log(`Found ${quotes.length} quote cards`);
  
  // ===== RESPONSIVE HANDLING =====
  
  // Function to check if device is mobile
  function isMobileDevice() {
    return window.innerWidth <= 768;
  }
  
  // Function to handle responsive UI elements
  function handleResponsiveElements() {
    const isMobile = isMobileDevice();
    
    // Handle action buttons visibility
    const actionButtons = document.querySelectorAll('.quote-actions');
    actionButtons.forEach(actionContainer => {
      actionContainer.style.display = isMobile ? 'none' : 'flex';
    });
    
    // Handle ellipsis menu visibility
    const menuButtons = document.querySelectorAll('.card-menu-btn');
    menuButtons.forEach(btn => {
      btn.style.display = isMobile ? 'flex' : 'none';
    });
    
    // Adjust card title padding for ellipsis button
    const cardTitles = document.querySelectorAll('.quote-card h2');
    cardTitles.forEach(title => {
      title.style.paddingRight = isMobile ? '2rem' : '0';
    });
  }
  
  // Initialize responsive elements
  handleResponsiveElements();
  
  // Update on window resize
  window.addEventListener('resize', function() {
    handleResponsiveElements();
    
    // Close sidebar on desktop
    if (window.innerWidth > 768 && sidebar && sidebar.classList.contains("active")) {
      sidebar.classList.remove("active");
      if (overlay) overlay.classList.remove("active");
      document.body.classList.remove("sidebar-open");
    }
    
    // Hide any open card menu when resizing
    hideCardMenu();
  });
  
  // ===== SIDEBAR FUNCTIONALITY =====
  
  function toggleSidebar() {
    if (!sidebar) return;
    
    sidebar.classList.toggle("active");
    if (overlay) overlay.classList.toggle("active");
    document.body.classList.toggle("sidebar-open");
  }
  
  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", toggleSidebar);
  }
  
  if (closeSidebar) {
    closeSidebar.addEventListener("click", toggleSidebar);
  }
  
  if (overlay) {
    overlay.addEventListener("click", toggleSidebar);
  }
  
  // ===== NAVIGATION FUNCTIONALITY =====
  
  const navButtons = document.querySelectorAll(".nav-button");
  const currentPath = window.location.pathname;
  
  navButtons.forEach((button) => {
    const href = button.getAttribute("href");
    if (href && (currentPath.endsWith(href) || currentPath.split("/").pop() === href)) {
      button.classList.add("active");
    }
    
    button.addEventListener("click", () => {
      navButtons.forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");
      
      // Close sidebar on mobile when a nav item is clicked
      if (isMobileDevice() && sidebar) {
        sidebar.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
        document.body.classList.remove("sidebar-open");
      }
    });
  });
  
  // ===== LOGOUT FUNCTIONALITY =====
  
  const logoutButton = document.querySelector(".logout-button");
  if (logoutButton) {
    logoutButton.addEventListener("click", () => {
      window.location.href = 'logout.jsp';
    });
  }
  
  // ===== SEARCH BAR VISIBILITY =====
  
  // Hide search bar if there are fewer than 5 quotes
  if (quotes.length < 5 && searchBar) {
    searchBar.style.display = "none";
    
    // Adjust content wrapper margin
    if (contentWrapper) {
      contentWrapper.style.marginTop = "var(--header-height)";
      contentWrapper.style.height = "calc(100vh - var(--header-height))";
      contentWrapper.style.display = "flex";
      contentWrapper.style.flexDirection = "column";
      
      // Make quote list take available space
      if (quotesList) {
        quotesList.style.flex = "1";
      }
      
      // Ensure pagination stays at bottom
      if (paginationContainer) {
        paginationContainer.style.marginTop = "auto";
      }
    }
  }
  
  // ===== PAGINATION FUNCTIONALITY =====
  
  let currentPage = 1;
  let itemsPerPage = getItemsPerPage();
  let filteredQuotes = [...quotes]; // Start with all quotes
  let totalPages = Math.ceil(filteredQuotes.length / itemsPerPage);
  
  function getItemsPerPage() {
    if (window.innerWidth <= 576) {
      return 3; // Small screens
    } else if (window.innerWidth <= 992) {
      return 4; // Medium screens
    } else {
      return 5; // Large screens
    }
  }
  
  // Update items per page when window is resized
  window.addEventListener("resize", function() {
    const newItemsPerPage = getItemsPerPage();
    if (newItemsPerPage !== itemsPerPage) {
      itemsPerPage = newItemsPerPage;
      totalPages = Math.ceil(filteredQuotes.length / itemsPerPage);
      displayQuotes();
      updatePagination();
    }
  });
  
  function displayQuotes() {
    // Hide all quotes first
    quotes.forEach((quote) => {
      quote.classList.remove("visible");
      quote.style.display = "none";
    });
    
    // Calculate start and end index for current page
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, filteredQuotes.length);
    
    // Show quotes for current page
    for (let i = startIndex; i < endIndex; i++) {
      if (filteredQuotes[i]) {
        filteredQuotes[i].classList.add("visible");
        filteredQuotes[i].style.display = "block";
      }
    }
  }
  
  function updatePagination() {
    if (!paginationContainer) return;
    
    const totalFilteredPages = Math.ceil(filteredQuotes.length / itemsPerPage);
    const pageNumbers = paginationContainer.querySelector(".page-numbers");
    if (!pageNumbers) return;
    
    const pageButtons = pageNumbers.querySelectorAll(".pagination-btn");
    const ellipsis = pageNumbers.querySelector(".ellipsis");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    
    // Update page buttons
    pageButtons.forEach((button, index) => {
      if (index === 0) {
        button.textContent = "1";
        button.style.display = totalFilteredPages > 0 ? "flex" : "none";
      } else if (index === pageButtons.length - 1) {
        button.textContent = totalFilteredPages.toString();
        button.style.display = totalFilteredPages > 1 ? "flex" : "none";
      } else {
        let pageNum;
        if (currentPage <= 3) {
          pageNum = index + 1;
        } else if (currentPage >= totalFilteredPages - 2) {
          pageNum = totalFilteredPages - (pageButtons.length - 2) + index;
        } else {
          pageNum = currentPage - 1 + index;
        }
        
        button.textContent = pageNum.toString();
        button.style.display = (pageNum > 1 && pageNum < totalFilteredPages) ? "flex" : "none";
      }
      
      button.classList.toggle("active", parseInt(button.textContent) === currentPage);
    });
    
    // Show/hide ellipsis
    if (ellipsis) {
      ellipsis.style.display = (totalFilteredPages > 5) ? "inline-block" : "none";
    }
    
    // Enable/disable prev/next buttons
    if (prevBtn) {
      prevBtn.disabled = currentPage === 1;
    }
    
    if (nextBtn) {
      nextBtn.disabled = currentPage === totalFilteredPages || totalFilteredPages === 0;
    }
    
    // Hide pagination if no results
    paginationContainer.style.display = totalFilteredPages > 0 ? "flex" : "none";
  }
  
  function changePage(newPage) {
    currentPage = newPage;
    displayQuotes();
    updatePagination();
    
    // Scroll to top of content when changing pages
    if (contentWrapper) {
      contentWrapper.scrollTop = 0;
    }
  }
  
  // Initialize pagination
  if (paginationContainer && quotes.length > 0) {
    updatePagination();
    displayQuotes();
    
    // Pagination event listeners
    const prevBtn = document.getElementById("prevBtn");
    if (prevBtn) {
      prevBtn.addEventListener("click", () => {
        if (currentPage > 1) changePage(currentPage - 1);
      });
    }
    
    const nextBtn = document.getElementById("nextBtn");
    if (nextBtn) {
      nextBtn.addEventListener("click", () => {
        const totalFilteredPages = Math.ceil(filteredQuotes.length / itemsPerPage);
        if (currentPage < totalFilteredPages) changePage(currentPage + 1);
      });
    }
    
    // Add event listeners to page number buttons
    document.querySelectorAll(".page-numbers .pagination-btn").forEach((button) => {
      button.addEventListener("click", (e) => {
        const newPage = parseInt(e.target.textContent);
        if (!isNaN(newPage)) changePage(newPage);
      });
    });
  } else {
    // If no pagination or no quotes, show all quotes
    quotes.forEach((quote) => {
      quote.style.display = "block";
    });
    
    // Hide pagination if no quotes
    if (paginationContainer && quotes.length === 0) {
      paginationContainer.style.display = "none";
    }
  }
  
  // ===== SEARCH FUNCTIONALITY =====
  
  if (searchInput && quotes.length >= 5) {
    searchInput.addEventListener("input", function(e) {
      const searchTerm = e.target.value.toLowerCase().trim();
      
      // Filter quotes based on search term
      filteredQuotes = quotes.filter((quote) => {
        const text = quote.textContent.toLowerCase();
        return text.includes(searchTerm);
      });
      
      // Reset to first page when searching
      currentPage = 1;
      
      // Update pagination based on filtered results
      totalPages = Math.ceil(filteredQuotes.length / itemsPerPage);
      updatePagination();
      
      // Display filtered quotes
      displayQuotes();
      
      // Show/hide no results message
      if (noResultsMessage) {
        noResultsMessage.style.display = filteredQuotes.length === 0 ? "flex" : "none";
      }
    });
  }
  
  // ===== CARD MENU FUNCTIONALITY =====
  
  // Variables to track current active menu
  let activeMenuBtn = null;
  let currentQuoteId = null;
  
  // Function to show card menu dropdown
  function showCardMenu(btn, quoteId) {
    // Only show menu on mobile devices
    if (!isMobileDevice() || !cardMenuDropdown) return;
    
    // Hide any previously open menu
    hideCardMenu();
    
    // Get button position
    const rect = btn.getBoundingClientRect();
    
    // Position dropdown near the button
    cardMenuDropdown.style.top = `${rect.bottom + window.scrollY}px`;
    cardMenuDropdown.style.left = `${rect.left + window.scrollX - 120}px`; // Align to right side of button
    
    // Store current quote ID
    currentQuoteId = quoteId;
    
    // Show dropdown
    cardMenuDropdown.classList.add('active');
    
    // Set active button
    activeMenuBtn = btn;
    btn.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    
    // Get quote status to show/hide menu items
    const quoteCard = btn.closest('.quote-card');
    const statusBadge = quoteCard.querySelector('.status-badge');
    const isPending = statusBadge && statusBadge.classList.contains('pending');
    
    // Show/hide approve and reject options based on status
    const approveItem = cardMenuDropdown.querySelector('.approve-item');
    const rejectItem = cardMenuDropdown.querySelector('.reject-item');
    
    if (approveItem) approveItem.style.display = isPending ? 'block' : 'none';
    if (rejectItem) rejectItem.style.display = isPending ? 'block' : 'none';
  }
  
  // Function to hide card menu dropdown
  function hideCardMenu() {
    if (!cardMenuDropdown) return;
    
    cardMenuDropdown.classList.remove('active');
    
    // Reset active button style
    if (activeMenuBtn) {
      activeMenuBtn.style.backgroundColor = '';
      activeMenuBtn = null;
    }
    
    // Reset current quote ID
    currentQuoteId = null;
  }
  
  // Add event listeners to card menu buttons
  const cardMenuBtns = document.querySelectorAll('.card-menu-btn');
  if (cardMenuBtns.length > 0) {
    cardMenuBtns.forEach(btn => {
      btn.addEventListener('click', function(e) {
        // Only process on mobile devices
        if (!isMobileDevice()) return;
        
        e.stopPropagation(); // Prevent event bubbling
        
        const quoteId = this.getAttribute('data-id');
        
        // If this button is already active, hide the menu
        if (activeMenuBtn === this) {
          hideCardMenu();
        } else {
          // Show menu for this button
          showCardMenu(this, quoteId);
        }
      });
    });
  }
  
  // Add event listeners to menu items
  if (cardMenuDropdown) {
    // View details item
    const viewDetailsItem = cardMenuDropdown.querySelector('.view-details-item');
    if (viewDetailsItem) {
      viewDetailsItem.addEventListener('click', function() {
        if (currentQuoteId) {
          window.location.href = `quote-details.jsp?id=${currentQuoteId}`;
        }
        hideCardMenu();
      });
    }
    
    // Approve item
    const approveItem = cardMenuDropdown.querySelector('.approve-item');
    if (approveItem) {
      approveItem.addEventListener('click', function() {
        if (currentQuoteId) {
          // Find the quote card to get the name
          const quoteCard = document.querySelector(`.card-menu-btn[data-id="${currentQuoteId}"]`).closest('.quote-card');
          if (quoteCard) {
            const nameElement = quoteCard.querySelector('h2');
            const name = nameElement ? nameElement.textContent : 'this quote';
            
            // Show approval modal
            showModal('approve', currentQuoteId, name);
          }
        }
        hideCardMenu();
      });
    }
    
    // Reject item
    const rejectItem = cardMenuDropdown.querySelector('.reject-item');
    if (rejectItem) {
      rejectItem.addEventListener('click', function() {
        if (currentQuoteId) {
          // Find the quote card to get the name
          const quoteCard = document.querySelector(`.card-menu-btn[data-id="${currentQuoteId}"]`).closest('.quote-card');
          if (quoteCard) {
            const nameElement = quoteCard.querySelector('h2');
            const name = nameElement ? nameElement.textContent : 'this quote';
            
            // Show rejection modal
            showModal('reject', currentQuoteId, name);
          }
        }
        hideCardMenu();
      });
    }
  }
  
  // Close menu when clicking outside
  document.addEventListener('click', function(e) {
    if (cardMenuDropdown && !cardMenuDropdown.contains(e.target) && 
        (!activeMenuBtn || !activeMenuBtn.contains(e.target))) {
      hideCardMenu();
    }
  });
  
  // Close menu on escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && cardMenuDropdown && cardMenuDropdown.classList.contains('active')) {
      hideCardMenu();
    }
  });
  
  // ===== MODAL FUNCTIONALITY =====
  
  function showModal(action, quoteId, quoteName) {
    if (!confirmModal || !modalTitle || !modalMessage || !confirmAction) return;
    
    if (action === 'approve') {
      modalTitle.textContent = `Do you want to approve ${quoteName}'s quote?`;
      modalMessage.textContent = "Once you approve this record you won't be able to undo this action.";
      confirmAction.textContent = `YES, APPROVE ${quoteName.toUpperCase()}'S QUOTE`;
      confirmAction.setAttribute('data-action', 'approve');
    } else if (action === 'reject') {
      modalTitle.textContent = `Do you want to reject ${quoteName}'s quote?`;
      modalMessage.textContent = "Once you reject this record you won't be able to undo this action.";
      confirmAction.textContent = `YES, REJECT ${quoteName.toUpperCase()}'S QUOTE`;
      confirmAction.setAttribute('data-action', 'reject');
    }
    
    confirmAction.setAttribute('data-id', quoteId);
    confirmModal.style.display = 'flex';
  }
  
  function closeModal() {
    if (confirmModal) {
      confirmModal.style.display = 'none';
    }
  }
  
  // Close modal when clicking the X button
  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }
  
  // Close modal when clicking the cancel button
  if (cancelAction) {
    cancelAction.addEventListener('click', closeModal);
  }
  
  // Close modal when clicking outside the modal content
  window.addEventListener('click', function(event) {
    if (event.target === confirmModal) {
      closeModal();
    }
  });
  
  // Close modal on Escape key
  document.addEventListener("keydown", function(e) {
    if (e.key === "Escape" && confirmModal && confirmModal.style.display === "flex") {
      closeModal();
    }
  });
  
  // ===== ACTION BUTTONS FUNCTIONALITY =====
  
  // View details button
  const viewDetailsBtns = document.querySelectorAll('.view-details-btn');
  if (viewDetailsBtns.length > 0) {
    viewDetailsBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const quoteId = this.getAttribute('data-id');
        if (quoteId) {
          // Redirect to quote details page
          window.location.href = `quote-details.jsp?id=${quoteId}`;
        }
      });
    });
  }
  
  // Approve button
  const approveBtns = document.querySelectorAll('.approve-btn');
  if (approveBtns.length > 0) {
    approveBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const quoteId = this.getAttribute('data-id');
        const quoteName = this.getAttribute('data-name') || 'this quote';
        showModal('approve', quoteId, quoteName);
      });
    });
  }
  
  // Reject button
  const rejectBtns = document.querySelectorAll('.reject-btn');
  if (rejectBtns.length > 0) {
    rejectBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const quoteId = this.getAttribute('data-id');
        const quoteName = this.getAttribute('data-name') || 'this quote';
        showModal('reject', quoteId, quoteName);
      });
    });
  }
  
  // Confirm button action
  if (confirmAction) {
    confirmAction.addEventListener('click', function() {
      const quoteId = this.getAttribute('data-id');
      const action = this.getAttribute('data-action');
      
      if (!quoteId || !action) {
        closeModal();
        return;
      }
      
      let endpoint = '';
      if (action === 'approve') {
        endpoint = 'approve-quote.jsp';
      } else if (action === 'reject') {
        endpoint = 'reject-quote.jsp';
      }
      
      if (endpoint) {
        // Send AJAX request
        fetch(`${endpoint}?id=${quoteId}`, {
          method: 'POST'
        })
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          if (data.success) {
            alert(`Quote ${action}d successfully!`);
            // Reload page to reflect changes
            window.location.reload();
          } else {
            alert('Error: ' + (data.message || 'Unknown error occurred'));
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert(`An error occurred while ${action}ing the quote.`);
        });
      }
      
      closeModal();
    });
  }
  
  // ===== TOUCH SWIPE FUNCTIONALITY =====
  
  let touchStartX = 0;
  let touchEndX = 0;
  
  if (quotesList) {
    quotesList.addEventListener("touchstart", function(e) {
      touchStartX = e.changedTouches[0].screenX;
    }, false);
    
    quotesList.addEventListener("touchend", function(e) {
      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
    }, false);
  }
  
  function handleSwipe() {
    const swipeThreshold = 100; // Minimum distance for swipe
    
    if (touchEndX < touchStartX - swipeThreshold) {
      // Swipe left - next page
      const totalFilteredPages = Math.ceil(filteredQuotes.length / itemsPerPage);
      if (currentPage < totalFilteredPages) changePage(currentPage + 1);
    }
    
    if (touchEndX > touchStartX + swipeThreshold) {
      // Swipe right - previous page
      if (currentPage > 1) changePage(currentPage - 1);
    }
  }
  
  // ===== KEYBOARD NAVIGATION =====
  
  document.addEventListener("keydown", function(e) {
    // Only handle arrow keys if no modal or dropdown is open
    if (confirmModal && confirmModal.style.display === "flex") return;
    if (cardMenuDropdown && cardMenuDropdown.classList.contains('active')) return;
    
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      const totalFilteredPages = Math.ceil(filteredQuotes.length / itemsPerPage);
      if (currentPage < totalFilteredPages) changePage(currentPage + 1);
    }
    
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      if (currentPage > 1) changePage(currentPage - 1);
    }
  });
  
  // ===== FALLBACK FOR JAVASCRIPT FAILURE =====
  
  // Make all cards visible initially if JavaScript fails to run properly
  if (quotes.length > 0) {
    quotes.forEach(quote => {
      quote.classList.add('visible');
    });
  }
});