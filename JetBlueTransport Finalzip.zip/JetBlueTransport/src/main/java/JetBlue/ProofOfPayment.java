package JetBlue;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/admin/receipt-image")
public class ProofOfPayment extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Enable CORS if needed
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET");
        
        String transferId = request.getParameter("id");
        if (transferId == null || transferId.isEmpty()) {
            sendErrorImage(response, "Missing transfer ID");
            return;
        }

        try (Connection con = ConnectionProvider.getCon()) {
            if (con == null || con.isClosed()) {
                sendErrorImage(response, "Database connection failed");
                return;
            }

            PreparedStatement ps = con.prepareStatement(
                "SELECT recite_pic FROM wireTransfer WHERE transfer_id = ?");
            ps.setInt(1, Integer.parseInt(transferId));
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                byte[] imageData = rs.getBytes("recite_pic");
                if (imageData != null && imageData.length > 0) {
                    // Determine content type
                    String contentType = determineContentType(imageData);
                    
                    // Set response headers
                    response.setContentType(contentType);
                    response.setContentLength(imageData.length);
                    response.setHeader("Cache-Control", "max-age=604800");
                    
                    // Write image data
                    try (OutputStream out = response.getOutputStream()) {
                        out.write(imageData);
                        return;
                    }
                }
            }
            sendErrorImage(response, "Image not found");
        } catch (Exception e) {
            e.printStackTrace();
            sendErrorImage(response, "Error: " + e.getMessage());
        }
    }
    
    private String determineContentType(byte[] imageData) {
        // Check for JPEG
        if (imageData.length >= 2 && 
            imageData[0] == (byte)0xFF && 
            imageData[1] == (byte)0xD8) {
            return "image/jpeg";
        }
        // Check for PNG
        if (imageData.length >= 8 && 
            imageData[0] == (byte)0x89 && 
            imageData[1] == (byte)0x50 && 
            imageData[2] == (byte)0x4E && 
            imageData[3] == (byte)0x47) {
            return "image/png";
        }
        // Default to JPEG
        return "image/jpeg";
    }
    
    private void sendErrorImage(HttpServletResponse response, String message) 
            throws IOException {
        response.setContentType("text/plain");
        response.getWriter().write(message);
    }
}