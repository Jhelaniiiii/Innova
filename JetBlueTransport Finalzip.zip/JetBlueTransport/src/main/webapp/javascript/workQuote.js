document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
    
    // Load required libraries
    function loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
            document.head.appendChild(script);
        });
    }

    Promise.all([
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'),
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js')
    ])
    .then(() => {
        console.log('All libraries loaded successfully');
        initializePDFFunctionality();
    })
    .catch(error => {
        console.error('Error loading libraries:', error);
        alert('Failed to load required PDF libraries. Please try again.');
    });

    function initializePDFFunctionality() {
        console.log('Initializing PDF functionality');
        
        if (!window.jspdf) {
            console.error('jsPDF not loaded correctly');
            return;
        }

        const { jsPDF } = window.jspdf;
        
        const getElement = (selector, required = true) => {
            const el = document.querySelector(selector);
            if (!el && required) {
                console.error(`Element not found: ${selector}`);
                throw new Error(`Required element missing: ${selector}`);
            }
            return el;
        };
        
        try {
            const addNewBtn1 = getElement('.add-new-btn');
            const addNewBtn2 = getElement('.add-new-btn2');
            const packingTable = getElement('#itemsTable');
            const laborTable = getElement('#itemsTable2');
            const transportTable = getElement('#itemsTable3');
            const saveBtn = getElement('.save-btn');

            // Add new item functionality
            if (addNewBtn1 && packingTable) {
                addNewBtn1.addEventListener('click', function() {
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td><input type="text"></td>
                        <td><input type="number" class="qty"></td>
                        <td><input type="number" class="unPrice"></td>
                        <td class="subtotal">$0</td>
                        <td><button class="remove-row">Remove</button></td>
                    `;
                    packingTable.appendChild(newRow);
                    updateTotal();
                });
            }

            if (addNewBtn2 && laborTable) {
                addNewBtn2.addEventListener('click', function() {
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td><input type="text"></td>
                        <td><input type="number" class="days"></td>
                        <td><input type="number" class="qty"></td>
                        <td><input type="number" class="unPrice"></td>
                        <td class="subtotal">$0</td>
                        <td><button class="remove-row">Remove</button></td>
                    `;
                    laborTable.appendChild(newRow);
                    updateTotal();
                });
            }

            // Remove row functionality
            if (packingTable) {
                packingTable.addEventListener('click', function(event) {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('tr');
                        row.remove();
                        updateTotal();
                    }
                });
            }

            if (laborTable) {
                laborTable.addEventListener('click', function(event) {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('tr');
                        row.remove();
                        updateTotal();
                    }
                });
            }

            // Calculate subtotal and total
            function setupTableListeners(table) {
                if (!table) return;
                
                table.addEventListener('input', function(event) {
                    const row = event.target.closest('tr');
                    if (!row) return;
                    
                    const qtyInput = row.querySelector('.qty');
                    const priceInput = row.querySelector('.unPrice');
                    const daysInput = row.querySelector('.days');
                    const subtotalCell = row.querySelector('.subtotal');
                    
                    if (!qtyInput || !priceInput || !subtotalCell) return;
                    
                    const qty = parseFloat(qtyInput.value) || 0;
                    const price = parseFloat(priceInput.value) || 0;
                    const days = daysInput ? (parseFloat(daysInput.value) || 0) : 1;
                    
                    const subtotal = qty * price * days;
                    subtotalCell.textContent = `$${subtotal.toFixed(2)}`;
                    updateTotal();
                });
            }

            setupTableListeners(packingTable);
            setupTableListeners(laborTable);
            setupTableListeners(transportTable);

            function updateTotal() {
                const subtotals = Array.from(document.querySelectorAll('.subtotal'))
                    .map(el => parseFloat(el.textContent.replace('$', '')) || 0);
                const total = subtotals.reduce((sum, value) => sum + value, 0);
                const totalElement = document.getElementById('totalAmount');
                if (totalElement) {
                    totalElement.textContent = `$${total.toFixed(2)}`;
                }
            }

            // Save button event listener
            if (saveBtn) {
                saveBtn.addEventListener('click', function() {
                    console.log('Generate PDF button clicked');
                    generatePDF();
                });
            }

            function generatePDF() {
                try {
                    const doc = new jsPDF();
                    let currentY = 20;
                    const pageHeight = doc.internal.pageSize.height;
                    const margin = 15;
                    const pageWidth = doc.internal.pageSize.getWidth();

                    function addNewPageIfNeeded(spaceNeeded) {
                        if (currentY + spaceNeeded > pageHeight - margin) {
                            doc.addPage();
                            currentY = margin;
                            // Add header on new pages
                            doc.setFontSize(10);
                            doc.setTextColor(112, 112, 112);
                            doc.text(`Jet Blue Transport Service - Page ${doc.internal.getNumberOfPages()}`, margin, currentY);
                            currentY += 10;
                        }
                    }

                    //logo handling with multiple fallbacks
                    const logo = new Image();
                    logo.crossOrigin = "Anonymous";
                    
                    const logoPaths = [
                        '../Images/Jet_Blue_LOGO.jpg',
                        '/Images/Jet_Blue_LOGO.jpg',
                        'Images/Jet_Blue_LOGO.jpg',
                        'file:///C:/Users/Tamra%20St.%20Hillaire/eclipse-workspace/JetBlueTransport/src/main/webapp/Images/Jet_Blue_LOGO.jpg'
                    ];
                    
                    let logoAttempts = 0;
                    
                    const tryNextLogo = () => {
                        if (logoAttempts < logoPaths.length) {
                            logo.src = logoPaths[logoAttempts++];
                        } else {
                            console.log("All logo attempts failed, proceeding without logo");
                            generateContent();
                        }
                    };
                    
                    logo.onload = function() {
                        try {
                            addNewPageIfNeeded(30);
                            doc.addImage(logo, 'JPEG', margin, currentY, 35, 30);
                            currentY += 9;
                            generateContent();
                        } catch (e) {
                            console.error("Error adding logo:", e);
                            tryNextLogo();
                        }
                    };
                    
                    logo.onerror = tryNextLogo;
                    tryNextLogo();

                    function generateContent() {
                        try {
                            // Header section
                            addNewPageIfNeeded(50);
                            doc.setFontSize(18);
                            doc.setFont("helvetica", "bold");
                            doc.setTextColor(5, 0, 154);
                            doc.text('Jet Blue Transport Service', 50, currentY);
                            currentY += 15;
                            
                            // Company address
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.setTextColor(112, 112, 112);
                            doc.text('16 Fatima Trace, Paramin, Maraval 121007', 50, currentY);
                            currentY += 7;
                            doc.text('Tel. No.: 721-2443 / 393-6449', 50, currentY);
                            currentY += 15;

                            // Quotation details
                            doc.setFontSize(12);
                            const quotNo = `Quotation No.: ${document.getElementById('invoiceNumber')?.value || ''}`;
                            const quotDate = `Quotation Date: ${document.getElementById('invoiceDate')?.value || new Date().toLocaleDateString()}`;
                            doc.text(quotNo, pageWidth - margin - doc.getTextWidth(quotNo), currentY - 15);
                            doc.text(quotDate, pageWidth - margin - doc.getTextWidth(quotDate), currentY - 8);

                            // Horizontal line
                            doc.setDrawColor(221, 221, 221);
                            doc.line(margin, currentY, pageWidth - margin, currentY);
                            currentY += 10;

                            // Client information
                            addNewPageIfNeeded(40);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Client Information:', margin, currentY);
                            currentY += 7;
                            doc.setFont("helvetica", "normal");
                            
                            const clientInfo = [
                                `Name: ${document.getElementById('clientName')?.value || ''}`,
                                `Phone: ${document.getElementById('clientNumber')?.value || ''}`,
                                `Email: ${document.getElementById('clientEmail')?.value || ''}`,
                                `Address: ${document.getElementById('clientAddress')?.value || ''}`
                            ];
                            
                            clientInfo.forEach((info, i) => {
                                doc.text(info, margin, currentY + (i * 7));
                            });
                            currentY += 28;

                            // From/To addresses
                            addNewPageIfNeeded(50);
                            doc.setFillColor(202, 217, 255);
                            doc.roundedRect(margin, currentY, 80, 40, 3, 3, 'F');
                            doc.roundedRect(105, currentY, 80, 40, 3, 3, 'F');
                            
                            doc.setFontSize(12);
                            doc.text('From:', margin + 5, currentY + 8);
                            const fromContent = document.querySelector('.from-address .address-content');
                            if (fromContent) {
                                const fromLines = Array.from(fromContent.children).map(el => el.textContent.trim());
                                fromLines.forEach((line, i) => doc.text(line, margin + 10, currentY + 15 + (i * 7)));
                            }
                            
                            doc.text('To:', 110, currentY + 8);
                            const toContent = document.querySelector('.to-address .address-content');
                            if (toContent) {
                                const toLines = Array.from(toContent.children).map(el => el.textContent.trim());
                                toLines.forEach((line, i) => doc.text(line, 115, currentY + 15 + (i * 7)));
                            }
                            currentY += 50;

                            // ===== PACKING MATERIALS SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Packing and Wrapping materials', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(Estimated amounts - any additional material required will be purchased at clients cost)', margin, currentY);
                            currentY += 10;
                            
                            // Collect packing data
                            const packingData = [['Description', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const packingRows = document.querySelectorAll('#itemsTable tr');
                            
                            packingRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && qtyInput && priceInput && subtotalCell) {
                                    packingData.push([
                                        descInput.value || '',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [packingData[0]],
                                body: packingData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 70 },
                                    1: { cellWidth: 25, halign: 'center' },
                                    2: { cellWidth: 35, halign: 'right' },
                                    3: { cellWidth: 35, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 10;

                            // ===== LABOUR SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Labour', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(packing, wrapping, dismantling households items/ loading on truck)', margin, currentY);
                            currentY += 10;
                            
                            // Collect labour data
                            const labourData = [['Description', 'Days', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const labourRows = document.querySelectorAll('#itemsTable2 tr');
                            
                            labourRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const daysInput = row.querySelector('.days');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && daysInput && qtyInput && priceInput && subtotalCell) {
                                    labourData.push([
                                        descInput.value || '',
                                        daysInput.value || '0',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [labourData[0]],
                                body: labourData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 50 },
                                    1: { cellWidth: 20, halign: 'center' },
                                    2: { cellWidth: 25, halign: 'center' },
                                    3: { cellWidth: 30, halign: 'right' },
                                    4: { cellWidth: 30, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 10;

                            // ===== TRANSPORT SECTION =====
                            addNewPageIfNeeded(50);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('Transport', margin, currentY);
                            currentY += 5;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");
                            doc.text('(Estimated amount of trips - any additional trips required will be at clients cost)', margin, currentY);
                            currentY += 10;
                            
                            // Collect transport data
                            const transportData = [['Description', 'Quantity', 'Unit Price (TT$)', 'Total(TT$)']];
                            const transportRows = document.querySelectorAll('#itemsTable3 tr');
                            
                            transportRows.forEach(row => {
                                const descInput = row.querySelector('td:first-child input');
                                const qtyInput = row.querySelector('.qty');
                                const priceInput = row.querySelector('.unPrice');
                                const subtotalCell = row.querySelector('.subtotal');
                                
                                if (descInput && qtyInput && priceInput && subtotalCell) {
                                    transportData.push([
                                        descInput.value || '',
                                        qtyInput.value || '0',
                                        priceInput.value || '0.00',
                                        subtotalCell.textContent || '$0.00'
                                    ]);
                                }
                            });
                            
                            doc.autoTable({
                                startY: currentY,
                                head: [transportData[0]],
                                body: transportData.slice(1),
                                margin: { left: margin },
                                styles: { fontSize: 9 },
                                columnStyles: {
                                    0: { cellWidth: 50 },
                                    1: { cellWidth: 25, halign: 'center' },
                                    2: { cellWidth: 35, halign: 'right' },
                                    3: { cellWidth: 35, halign: 'right' }
                                },
                                didDrawPage: function(data) {
                                    currentY = data.cursor.y + 10;
                                }
                            });
                            currentY = doc.lastAutoTable.finalY + 15;

                            // Terms and conditions
                            addNewPageIfNeeded(100);
                            doc.setFontSize(12);
                            doc.setFont("helvetica", "bold");
                            doc.text('TERMS AND CONDITIONS', margin, currentY);
                            currentY += 7;
                            doc.setFontSize(10);
                            doc.setFont("helvetica", "normal");

                            const terms = [
                                '1. 50% down payment is required to start',
                                '2. Balance due upon completion',
                                '3. Any additional works required will be billed separately',
                                '4. This quotation is valid for thirty (30) days',
                                '5. Credit JMMB Bank Account No.:007600014296'
                            ];

                            terms.forEach((term, index) => {
                                if (currentY > pageHeight - 20) {
                                    doc.addPage();
                                    currentY = margin;
                                }
                                doc.text(term, margin + 5, currentY);
                                currentY += 7;
                            });

                            // Add space after terms
                            currentY += 10;

                            // Signature handling
                            const signature = new Image();
                            signature.crossOrigin = "Anonymous";

                            const signaturePaths = [
                                '../Images/Signature.png',
                                '/Images/Signature.png',
                                'Images/Signature.png',
                                'file:///C:/Users/Tamra%20St.%20Hillaire/eclipse-workspace/JetBlueTransport/src/main/webapp/Images/Signature.png'
                            ];

                            let signatureAttempts = 0;

                            const tryNextSignature = () => {
                                if (signatureAttempts < signaturePaths.length) {
                                    signature.src = signaturePaths[signatureAttempts++];
                                } else {
                                    console.log("All signature attempts failed, proceeding without signature");
                                    // Proceed to total amount even if signature fails
                                    addTotalAmount();
                                }
                            };

                            signature.onload = function() {
                                try {
                                    addNewPageIfNeeded(30);
                                    doc.addImage(signature, 'PNG', margin, currentY, 60, 10);
                                    //currentY += 40; // Add space after signature
                                    addTotalAmount();
                                } catch (e) {
                                    console.error("Error adding signature:", e);
                                    tryNextSignature();
                                }
                            };

                            signature.onerror = tryNextSignature;
                            tryNextSignature();

                            function addTotalAmount() {
                                // Total amount
                                addNewPageIfNeeded(30);
                                const totalY = currentY + 10;
                                doc.setFillColor(202, 217, 255);
                                doc.roundedRect(140, totalY - 10, 50, 20, 3, 3, 'F');
                                
                                doc.setFontSize(14);
                                doc.text('Total:', 145, totalY - 3);
                                doc.setFontSize(16);
                                doc.setFont("helvetica", "bold");
                                doc.setTextColor(5, 0, 154);
                                const totalAmount = document.getElementById('totalAmount')?.textContent || '$0.00';
                                doc.text(totalAmount, 160, totalY - 3);

                                // Save the PDF
                                const invoiceNumber = document.getElementById('invoiceNumber')?.value || 'JB-QUOTE';
                                console.log('Saving PDF...');
                                doc.save(`JetBlue_Quotation_${invoiceNumber}.pdf`);
                                console.log('PDF saved successfully');
                            }
                        } catch (contentError) {
                            console.error('Error generating PDF content:', contentError);
                            alert('Error generating PDF content. Please check console for details.');
                        }
                    }
                } catch (pdfError) {
                    console.error('Error creating PDF:', pdfError);
                    alert('Failed to create PDF. Please check console for details.');
                }
            }
            
            // Initialize total
            updateTotal();
            console.log('PDF functionality initialized successfully');
        } catch (initError) {
            console.error('Error initializing PDF functionality:', initError);
            alert('Failed to initialize PDF functionality. Please check console for details.');
        }
    }
});