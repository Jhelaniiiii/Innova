document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality from J-code
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.classList.add("hovered")
    })

    item.addEventListener("mouseleave", () => {
      item.classList.remove("hovered")
    })

    item.addEventListener("click", () => {
      // Remove active class from all items
      document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"))
      // Add active class to the clicked item
      item.classList.add("active")
    })
  })

  // Calendar functionality
  const monthDisplay = document.getElementById("month-display")
  const yearDisplay = document.getElementById("year-display")
  const calendarDays = document.getElementById("calendar-days")
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")
  const yearPopup = document.getElementById("year-popup")
  const yearGrid = document.getElementById("year-grid")
  const closeYearPopup = document.getElementById("close-year-popup")
  const addEventBtn = document.getElementById("add-event-btn")
  const eventPopup = document.getElementById("event-popup")
  const closeEventPopup = document.getElementById("close-event-popup")
  const saveEventBtn = document.getElementById("save-event")

  // Set initial date to current date
  const currentDate = new Date()
  const today = new Date()
  
  // Set today to start of day for accurate comparisons
  today.setHours(0, 0, 0, 0)
  
  // Set range of years to display in the popup (current year -5 to +10)
  const currentYear = new Date().getFullYear()
  const startYear = currentYear - 5
  const endYear = currentYear + 10

  // Store events
  let events = {}
  
  // Track if add event mode is active
  let addEventMode = false
  let selectedDate = null

  // Maximum appointments per day
  const MAX_APPOINTMENTS_PER_DAY = 2

  // Month names
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Function to check if a date is in the past
  function isPastDate(year, month, day) {
    const date = new Date(year, month, day)
    date.setHours(0, 0, 0, 0)
    return date < today
  }
  
  // Function to check if a date has reached maximum appointments
  function isDateFull(year, month, day) {
    const dateKey = `${year}-${month}-${day}`
    return events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY
  }

  // Function to render the calendar
  function renderCalendar() {
    // Update month and year display
    monthDisplay.textContent = months[currentDate.getMonth()]
    yearDisplay.textContent = currentDate.getFullYear()

    // Clear previous days
    calendarDays.innerHTML = ""

    // Get first day of month and last day of month
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    // Get the day of the week for the first day (0 is Sunday, 1 is Monday, etc.)
    // Adjust to make Monday the first day (0)
    let firstDayIndex = firstDay.getDay() - 1
    if (firstDayIndex < 0) firstDayIndex = 6 // Sunday becomes 6

    // Get the number of days in the previous month
    const prevLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
    const prevDaysCount = prevLastDay.getDate()

    // Get the number of days in the current month
    const daysInMonth = lastDay.getDate()

    // Calculate total cells needed (previous month days + current month days + next month days)
    const totalCells = Math.ceil((firstDayIndex + daysInMonth) / 7) * 7

    // Render days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${prevDaysCount - i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day")
      
      // Check if this day is today
      const isToday = 
        i === today.getDate() && 
        currentDate.getMonth() === today.getMonth() && 
        currentDate.getFullYear() === today.getFullYear()
      
      if (isToday) {
        dayElement.classList.add("today")
      }
      
      // Check if this day is in the past
      const isPast = isPastDate(currentDate.getFullYear(), currentDate.getMonth(), i)
      if (isPast) {
        dayElement.classList.add("past-date")
      }
      
      // Create day number element
      const dayNumberElement = document.createElement("div")
      dayNumberElement.classList.add("day-number")
      dayNumberElement.textContent = i
      dayElement.appendChild(dayNumberElement)
      
      // Store date information as data attributes
      dayElement.dataset.day = i
      dayElement.dataset.month = currentDate.getMonth()
      dayElement.dataset.year = currentDate.getFullYear()
      
      // Check if there are events for this day and render them
      const dateKey = `${currentDate.getFullYear()}-${currentDate.getMonth()}-${i}`
      if (events[dateKey]) {
        events[dateKey].forEach(event => {
          const eventElement = document.createElement("div")
          eventElement.classList.add("event")
          eventElement.textContent = event.title
          dayElement.appendChild(eventElement)
        })
        
        // Check if day has reached maximum appointments
        if (events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
          dayElement.classList.add("full")
        }
      }
      
      // Add click event to select a day only if it's not in the past and not full
      if (!isPast && !isDateFull(currentDate.getFullYear(), currentDate.getMonth(), i)) {
        dayElement.addEventListener("click", () => {
          if (addEventMode) {
            // If in add event mode, show event popup
            selectedDate = {
              day: i,
              month: currentDate.getMonth(),
              year: currentDate.getFullYear()
            }
            
            // Show the event creation popup
            document.getElementById("event-title").value = ""
            document.getElementById("event-time").value = ""
            document.getElementById("event-description").value = ""
            eventPopup.classList.add("active")
          } else {
            // Regular day selection
            // Remove selected class from all days
            document.querySelectorAll(".day").forEach(day => {
              day.classList.remove("selected")
            })
            // Add selected class to clicked day
            dayElement.classList.add("selected")
          }
        })
      }
      
      // If it's today, automatically select it (unless it's full)
      if (isToday && !isDateFull(currentDate.getFullYear(), currentDate.getMonth(), i)) {
        dayElement.classList.add("selected")
      }
      
      calendarDays.appendChild(dayElement)
    }

    // Render days from next month
    const remainingCells = totalCells - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= remainingCells; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }
  }

  // Function to populate the year selection popup
  function populateYearGrid() {
    yearGrid.innerHTML = ""
    
    for (let year = startYear; year <= endYear; year++) {
      const yearButton = document.createElement("button")
      yearButton.classList.add("year-option")
      yearButton.textContent = year
      
      // Highlight the current selected year
      if (year === currentDate.getFullYear()) {
        yearButton.classList.add("selected")
      }
      
      // Add click event to select a year
      yearButton.addEventListener("click", () => {
        // Set the new year
        currentDate.setFullYear(year)
        
        // Update the calendar
        renderCalendar()
        
        // Close the popup
        yearPopup.classList.remove("active")
      })
      
      yearGrid.appendChild(yearButton)
    }
  }

  // Function to add a new event
  function addEvent(day, month, year, title, time, description) {
    const dateKey = `${year}-${month}-${day}`
    
    // Check if date already has maximum appointments
    if (events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
      alert(`Sorry, this day already has the maximum of ${MAX_APPOINTMENTS_PER_DAY} appointments.`)
      return false
    }
    
    if (!events[dateKey]) {
      events[dateKey] = []
    }
    
    events[dateKey].push({
      title,
      time,
      description
    })
    
    // Re-render the calendar to show the new event
    renderCalendar()
    return true
  }

  // Time slot selection handling
  const timeSlots = document.querySelectorAll(".time-slot")
  timeSlots.forEach((slot) => {
    slot.addEventListener("click", function () {
      // Remove selected class from all slots
      timeSlots.forEach((s) => s.classList.remove("selected"))
      // Add selected class to clicked slot
      this.classList.add("selected")
    })
  })

  // Event listeners for month navigation
  prevMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    renderCalendar()
  })

  nextMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    renderCalendar()
  })
  
  // Event listener for year display click
  yearDisplay.addEventListener("click", () => {
    // Populate the year grid
    populateYearGrid()
    
    // Show the popup
    yearPopup.classList.add("active")
  })
  
  // Event listener for close popup button
  closeYearPopup.addEventListener("click", () => {
    yearPopup.classList.remove("active")
  })
  
  // Close popup when clicking outside
  yearPopup.addEventListener("click", (e) => {
    if (e.target === yearPopup) {
      yearPopup.classList.remove("active")
    }
  })
  
  // Event listener for add event button
  addEventBtn.addEventListener("click", () => {
    addEventMode = !addEventMode
    
    if (addEventMode) {
      addEventBtn.classList.add("active")
    } else {
      addEventBtn.classList.remove("active")
    }
  })
  
  // Event listener for close event popup button
  closeEventPopup.addEventListener("click", () => {
    eventPopup.classList.remove("active")
    selectedDate = null
  })
  
  // Close event popup when clicking outside
  eventPopup.addEventListener("click", (e) => {
    if (e.target === eventPopup) {
      eventPopup.classList.remove("active")
      selectedDate = null
    }
  })
  
  // Event listener for save event button
  saveEventBtn.addEventListener("click", () => {
    if (selectedDate) {
      const title = document.getElementById("event-title").value
      const time = document.getElementById("event-time").value
      const description = document.getElementById("event-description").value
      
      if (title.trim() !== "") {
        const success = addEvent(
          selectedDate.day,
          selectedDate.month,
          selectedDate.year,
          title,
          time,
          description
        )
        
        if (success) {
          // Close the popup
          eventPopup.classList.remove("active")
          
          // Exit add event mode
          addEventMode = false
          addEventBtn.classList.remove("active")
          selectedDate = null
        }
      } else {
        alert("Please enter an event title")
      }
    }
  })

  // Initial render
  renderCalendar()

  // Handle booking form submission
  const bookingButton = document.querySelector(".book-appointment")
  if (bookingButton) {
    bookingButton.addEventListener("click", (e) => {
      e.preventDefault()

      // Get selected time slot
      const selectedTime = document.querySelector(".time-slot.selected")
      const selectedTimeValue = selectedTime ? selectedTime.textContent : null

      // Get selected date from calendar
      const selectedDay = document.querySelector(".day.selected .day-number")
      const selectedDayValue = selectedDay ? selectedDay.textContent : null
      
      // Format the selected date
      let selectedDate = "Not selected"
      if (selectedDayValue) {
        selectedDate = `${months[currentDate.getMonth()]} ${selectedDayValue}, ${currentDate.getFullYear()}`
      }

      // Check if a date is selected
      if (selectedDayValue === null) {
        alert("Please select a date on the calendar")
        return
      }

      // Check if a time slot is selected
      if (selectedTimeValue === null) {
        alert("Please select a time slot")
        return
      }

      // You can add validation and submission logic here
      console.log("Booking submitted:", {
        date: selectedDate,
        time: selectedTimeValue,
        to: {
          area: document.querySelector(".location-section:nth-child(1) .form-group:nth-child(1) input").value || "East",
          street: document.querySelector(".location-section:nth-child(1) .form-group:nth-child(2) input").value || "#12 Lane, Arthia",
          info: document.querySelector(".location-section:nth-child(1) .form-group.full-width input").value || "By the big tree, passed the red abandoned house on the right",
        },
        from: {
          area: document.querySelector(".location-section:nth-child(2) .form-group:nth-child(1) input").value || "South",
          street: document.querySelector(".location-section:nth-child(2) .form-group:nth-child(2) input").value || "#34 Prakash Street, Delhi",
          info: document.querySelector(".location-section:nth-child(2) .form-group.full-width input").value || "Near the police station, by the green shed",
        },
        service: document.querySelector(".service-section input").value,
      })
      
      // Add the booking as an event
      const day = parseInt(selectedDayValue)
      const success = addEvent(
        day,
        currentDate.getMonth(),
        currentDate.getFullYear(),
        "Booking: " + selectedTimeValue,
        selectedTimeValue,
        "Transport booking"
      )
      
      if (success) {
        alert("Booking confirmed!")
      }
    })
  }
})