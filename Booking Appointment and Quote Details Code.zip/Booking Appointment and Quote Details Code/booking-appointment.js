document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.classList.add("hovered")
    })

    item.addEventListener("mouseleave", () => {
      item.classList.remove("hovered")
    })

    item.addEventListener("click", () => {
      // Remove active class from all items
      document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"))
      // Add active class to the clicked item
      item.classList.add("active")
    })
  })

  // Calendar functionality
  const monthDisplay = document.getElementById("month-display")
  const yearDisplay = document.getElementById("year-display")
  const calendarDays = document.getElementById("calendar-days")
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")
  const yearPopup = document.getElementById("year-popup")
  const yearGrid = document.getElementById("year-grid")
  const closeYearPopup = document.getElementById("close-year-popup")
  const addEventBtn = document.getElementById("add-event-btn")
  const linkEventBtn = document.getElementById("link-event-btn")
  const eventPopup = document.getElementById("event-popup")
  const closeEventPopup = document.getElementById("close-event-popup")
  const saveEventBtn = document.getElementById("save-event")
  const deleteEventBtn = document.getElementById("delete-event")
  const eventDetailsPopup = document.getElementById("event-details-popup")
  const closeDetailsPopup = document.getElementById("close-details-popup")
  const editEventDetailsBtn = document.getElementById("edit-event")
  const closeDetailsBtn = document.getElementById("close-details")
  const calendar = document.querySelector(".calendar")
  const bookingForm = document.querySelector(".booking-form")

  // Set initial date to current date
  const currentDate = new Date()
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Initialize events from server data
  let events = {}
  if (window.serverEvents && Object.keys(window.serverEvents).length > 0) {
    events = window.serverEvents
  }

  // Load saved events from localStorage and merge with server events
  const savedEvents = localStorage.getItem("calendarEvents")
  if (savedEvents) {
    const localEvents = JSON.parse(savedEvents)
    // Merge local events with server events (server events take precedence)
    Object.keys(localEvents).forEach((dateKey) => {
      if (!events[dateKey]) {
        events[dateKey] = localEvents[dateKey]
      }
    })
  }

  // Month mapping and helper functions
  const monthMap = {
    "01": "January",
    "02": "February",
    "03": "March",
    "04": "April",
    "05": "May",
    "06": "June",
    "07": "July",
    "08": "August",
    "09": "September",
    10: "October",
    11: "November",
    12: "December",
  }

  function getMonthNumber(monthIndex) {
    return (monthIndex + 1).toString().padStart(2, "0")
  }

  function getMonthName(monthNumber) {
    return monthMap[monthNumber] || monthMap[getMonthNumber(currentDate.getMonth())]
  }

  // Set range of years to display in the popup (current year -5 to +10)
  const currentYear = new Date().getFullYear()
  const startYear = currentYear - 0
  const endYear = currentYear + 10

  // Track if add event mode is active
  let addEventMode = false
  let linkEventMode = false
  let selectedDate = null
  let selectedEvent = null
  let linkedEventId = null
  let linkedEventData = null // Store complete linked event data

  // Maximum appointments per day
  const MAX_APPOINTMENTS_PER_DAY = 2

  // Function to check if a date is in the past
  function isPastDate(year, month, day) {
    const date = new Date(year, month - 1, day)
    date.setHours(0, 0, 0, 0)
    return date < today
  }

  // Function to check if a date has reached maximum appointments
  function isDateFull(year, month, day) {
    const dateKey = `${year}-${month}-${day}`
    return events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY
  }

  // Function to parse time string to hours and minutes
  function parseTimeString(timeStr) {
    if (!timeStr) return null

    // Extract hours, minutes, and AM/PM
    const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i)
    if (!match) return null

    let hours = Number.parseInt(match[1])
    const minutes = Number.parseInt(match[2])
    const ampm = match[3].toUpperCase()

    // Convert to 24-hour format
    if (ampm === "PM" && hours < 12) hours += 12
    if (ampm === "AM" && hours === 12) hours = 0

    return { hours, minutes }
  }

  // Function to check if a time is within 2 hours of existing appointments
  function isTimeWithinTwoHours(dateKey, timeStr) {
    if (!events[dateKey] || events[dateKey].length === 0) return false

    const newTime = parseTimeString(timeStr)
    if (!newTime) return false

    const newTimeMinutes = newTime.hours * 60 + newTime.minutes

    for (const event of events[dateKey]) {
      const existingTime = parseTimeString(event.time)
      if (!existingTime) continue

      const existingTimeMinutes = existingTime.hours * 60 + existingTime.minutes
      const diffMinutes = Math.abs(newTimeMinutes - existingTimeMinutes)

      if (diffMinutes < 120) {
        return true
      }
    }

    return false
  }

  // Function to populate time slots in the event form
  function populateTimeSlots() {
    const timeSelect = document.getElementById("event-time-select")
    if (!timeSelect) return

    timeSelect.innerHTML = '<option value="">Select a time</option>'

    const dateKey = selectedDate ? `${selectedDate.year}-${selectedDate.month}-${selectedDate.day}` : null

    for (let hour = 9; hour <= 16; hour++) {
      const hourStr = hour > 12 ? hour - 12 : hour
      const ampm = hour >= 12 ? "PM" : "AM"

      const fullHourTimeStr = `${hourStr}:00 ${ampm}`
      const fullHourBlocked = dateKey && isTimeWithinTwoHours(dateKey, fullHourTimeStr)

      if (
        !fullHourBlocked ||
        (selectedEvent && events[selectedEvent.dateKey][selectedEvent.index].time === fullHourTimeStr)
      ) {
        const fullHourOption = document.createElement("option")
        fullHourOption.value = fullHourTimeStr
        fullHourOption.textContent = fullHourTimeStr
        timeSelect.appendChild(fullHourOption)
      }

      if (hour < 16) {
        const halfHourTimeStr = `${hourStr}:30 ${ampm}`
        const halfHourBlocked = dateKey && isTimeWithinTwoHours(dateKey, halfHourTimeStr)

        if (
          !halfHourBlocked ||
          (selectedEvent && events[selectedEvent.dateKey][selectedEvent.index].time === halfHourTimeStr)
        ) {
          const halfHourOption = document.createElement("option")
          halfHourOption.value = halfHourTimeStr
          halfHourOption.textContent = halfHourTimeStr
          timeSelect.appendChild(halfHourOption)
        }
      }
    }

    if (timeSelect.options.length === 1) {
      const noSlotsOption = document.createElement("option")
      noSlotsOption.value = ""
      noSlotsOption.textContent = "No available times (all within 2 hours of existing appointments)"
      noSlotsOption.disabled = true
      timeSelect.appendChild(noSlotsOption)
    }
  }

  // Function to format date for display
  function formatDateForDisplay(dateKey) {
    const [year, month, day] = dateKey.split("-")
    return `${getMonthName(month)} ${Number.parseInt(day)}, ${year}`
  }

  // Function to populate booking form with event data and set up for linking
  function populateBookingForm(dateKey, eventIndex) {
    const event = events[dateKey][eventIndex]
    if (!event) return

    // Store the linked event ID and complete data
    linkedEventId = event.id
    linkedEventData = {
      dateKey: dateKey,
      eventIndex: eventIndex,
      event: event,
    }

    document.getElementById("linked-event-id").value = linkedEventId

    // Change form action to update_appointment
    document.getElementById("form-action").value = "update_appointment"

    // Populate the form fields
    document.getElementById("booking-title").value = event.title || ""
    document.getElementById("booking-date").value = formatDateForDisplay(dateKey)
    document.getElementById("booking-time").value = event.time || ""
    document.getElementById("booking-description").value = event.description || ""

    // Pre-populate existing booking data if available
    if (event.to_area) document.getElementById("to-area").value = event.to_area
    if (event.to_street) document.getElementById("to-street").value = event.to_street
    if (event.to_info) document.getElementById("to-info").value = event.to_info
    if (event.from_area) document.getElementById("from-area").value = event.from_area
    if (event.from_street) document.getElementById("from-street").value = event.from_street
    if (event.from_info) document.getElementById("from-info").value = event.from_info
    if (event.service) document.getElementById("service").value = event.service

    // Add visual feedback
    bookingForm.classList.add("linked-mode")
    document.getElementById("submit-btn").textContent = "Update Event with Booking Details"

    // Show success message
    alert("Event linked to booking form! Complete the booking details and submit to update the event.")

    // Deactivate link mode
    linkEventMode = false
    linkEventBtn.classList.remove("active")
    calendar.classList.remove("link-mode")
  }

  // Function to reset booking form to normal mode
  function resetBookingForm() {
    linkedEventId = null
    linkedEventData = null
    document.getElementById("linked-event-id").value = ""
    document.getElementById("form-action").value = "book_appointment"
    bookingForm.classList.remove("linked-mode")
    document.getElementById("submit-btn").textContent = "Book Appointment"

    // Clear form fields
    document.getElementById("booking-title").value = ""
    document.getElementById("booking-date").value = ""
    document.getElementById("booking-time").value = ""
    document.getElementById("booking-description").value = ""
    document.getElementById("to-area").selectedIndex = 0
    document.getElementById("to-street").value = ""
    document.getElementById("to-info").value = ""
    document.getElementById("from-area").selectedIndex = 0
    document.getElementById("from-street").value = ""
    document.getElementById("from-info").value = ""
    document.getElementById("service").selectedIndex = 0
  }

  // Function to render the calendar
  function renderCalendar() {
    const currentMonthNumber = getMonthNumber(currentDate.getMonth())
    monthDisplay.textContent = getMonthName(currentMonthNumber)
    yearDisplay.textContent = currentDate.getFullYear()

    calendarDays.innerHTML = ""

    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    let firstDayIndex = firstDay.getDay() - 1
    if (firstDayIndex < 0) firstDayIndex = 6

    const prevLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
    const prevDaysCount = prevLastDay.getDate()
    const daysInMonth = lastDay.getDate()
    const totalCells = Math.ceil((firstDayIndex + daysInMonth) / 7) * 7

    // Render days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${prevDaysCount - i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day")

      const isToday =
        i === today.getDate() &&
        currentDate.getMonth() === today.getMonth() &&
        currentDate.getFullYear() === today.getFullYear()

      if (isToday) {
        dayElement.classList.add("today")
      }

      const isPast = isPastDate(currentDate.getFullYear(), currentDate.getMonth() + 1, i)
      if (isPast) {
        dayElement.classList.add("past-date")
      }

      const dayNumberElement = document.createElement("div")
      dayNumberElement.classList.add("day-number")
      dayNumberElement.textContent = i
      dayElement.appendChild(dayNumberElement)

      const currentMonthNumber = getMonthNumber(currentDate.getMonth())
      dayElement.dataset.day = i
      dayElement.dataset.month = currentMonthNumber
      dayElement.dataset.year = currentDate.getFullYear()

      const dateKey = `${currentDate.getFullYear()}-${currentMonthNumber}-${i}`
      if (events[dateKey]) {
        events[dateKey].forEach((event, index) => {
          const eventElement = document.createElement("div")
          eventElement.classList.add("event")
          eventElement.dataset.index = index
          eventElement.dataset.eventId = event.id // Store event ID

          const titleElement = document.createElement("div")
          titleElement.textContent = event.title
          eventElement.appendChild(titleElement)

          if (event.time) {
            const timeElement = document.createElement("div")
            timeElement.classList.add("event-time")
            timeElement.textContent = event.time
            eventElement.appendChild(timeElement)
          }

          eventElement.addEventListener("click", (e) => {
            e.stopPropagation()

            // Check if we're in link mode
            if (linkEventMode) {
              populateBookingForm(dateKey, index)
            } else {
              showEventDetails(dateKey, index)
            }
          })

          dayElement.appendChild(eventElement)
        })

        if (events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
          dayElement.classList.add("full")
        }
      }

      if (!isPast && !isDateFull(currentDate.getFullYear(), currentMonthNumber, i)) {
        dayElement.addEventListener("click", () => {
          if (addEventMode) {
            selectedDate = {
              day: i,
              month: currentMonthNumber,
              year: currentDate.getFullYear(),
            }

            document.getElementById("event-popup-title").textContent = "Add New Event"
            document.getElementById("event-title").value = ""
            document.getElementById("event-time-select").value = ""
            document.getElementById("event-description").value = ""
            document.getElementById("event-id").value = ""

            deleteEventBtn.style.display = "none"
            populateTimeSlots()
            eventPopup.classList.add("active")
          } else if (!linkEventMode) {
            document.querySelectorAll(".day").forEach((day) => {
              day.classList.remove("selected")
            })
            dayElement.classList.add("selected")

            // Store selected date information for booking form
            selectedDate = {
              day: i,
              month: currentMonthNumber,
              year: currentDate.getFullYear(),
            }

            // Update booking form with selected date
            const selectedDateStr = `${getMonthName(currentMonthNumber)} ${i}, ${currentDate.getFullYear()}`
            document.getElementById("booking-date").value = selectedDateStr
          }
        })
      }

      if (isToday && !isDateFull(currentDate.getFullYear(), currentMonthNumber, i)) {
        dayElement.classList.add("selected")
        // Set today as the default selected date
        selectedDate = {
          day: i,
          month: currentMonthNumber,
          year: currentDate.getFullYear(),
        }
        const selectedDateStr = `${getMonthName(currentMonthNumber)} ${i}, ${currentDate.getFullYear()}`
        document.getElementById("booking-date").value = selectedDateStr
      }

      calendarDays.appendChild(dayElement)
    }

    // Render days from next month
    for (let i = 1; i <= totalCells - (firstDayIndex + daysInMonth); i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }
  }

  // Function to show event details
  function showEventDetails(dateKey, index) {
    if (events[dateKey] && events[dateKey][index]) {
      const event = events[dateKey][index]
      selectedEvent = { dateKey, index }

      const [year, month, day] = dateKey.split("-")
      const formattedDate = `${getMonthName(month)} ${day}, ${year}`

      document.getElementById("detail-title").textContent = event.title
      document.getElementById("detail-date").textContent = formattedDate
      document.getElementById("detail-time").textContent = event.time || "Not specified"
      document.getElementById("detail-description").textContent = event.description || "No description"

      eventDetailsPopup.classList.add("active")
    }
  }

  // Function to populate the year selection popup
  function populateYearGrid() {
    yearGrid.innerHTML = ""

    for (let year = startYear; year <= endYear; year++) {
      const yearButton = document.createElement("button")
      yearButton.classList.add("year-option")
      yearButton.textContent = year

      if (year === currentDate.getFullYear()) {
        yearButton.classList.add("selected")
      }

      yearButton.addEventListener("click", () => {
        currentDate.setFullYear(year)
        renderCalendar()
        yearPopup.classList.remove("active")
      })

      yearGrid.appendChild(yearButton)
    }
  }

// Add event Function
  function addEvent(day, month, year, title, time, description) {
  const dateKey = `${year}-${month}-${day}`

  if (events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
    alert(`Sorry, this day already has the maximum of ${MAX_APPOINTMENTS_PER_DAY} appointments.`)
    return false
  }

  if (isTimeWithinTwoHours(dateKey, time)) {
    alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
    return false
  }

  if (!events[dateKey]) {
    events[dateKey] = []
  }

  // Generate a unique temporary ID for locally created events
  const tempId = `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

  events[dateKey].push({
    id: tempId, // Add ID for linking
    title,
    time,
    description,
  })

  localStorage.setItem("calendarEvents", JSON.stringify(events))
  renderCalendar()
  return true
}

// Update function
function updateEvent(eventId, day, month, year, title, time, description) {
  const dateKey = `${year}-${month}-${day}`

  if (!events[dateKey]) {
    console.error("No events found for this date")
    return false
  }

  const eventIndex = events[dateKey].findIndex(
    (event) => event.id.toString() === eventId.toString()
  )

  if (eventIndex === -1) {
    console.error("Event not found")
    return false
  }

  const originalEvent = events[dateKey][eventIndex]
  const originalTime = originalEvent.time
  const originalId = originalEvent.id

  // Temporarily remove event for time conflict validation
  const tempEvent = events[dateKey].splice(eventIndex, 1)[0]

  if (time !== originalTime && isTimeWithinTwoHours(dateKey, time)) {
    // Reinsert if blocked
    events[dateKey].splice(eventIndex, 0, tempEvent)
    alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
    return false
  }

  // Update and reinsert
  events[dateKey].splice(eventIndex, 0, {
    id: originalId,
    title,
    time,
    description,
  })

  // Save and refresh
  localStorage.setItem("calendarEvents", JSON.stringify(events))
  renderCalendar()
  return true
}

// FIXED: Delete function with immediate calendar update for server events
function deleteEvent(dateKey, index) {
  if (events[dateKey] && events[dateKey][index]) {
    const event = events[dateKey][index]
    const eventId = event.id
      
    // Check if this is a server event (has numeric ID) or local event (has string ID starting with 'local_')
    if (eventId && !eventId.toString().startsWith('local_')) {
      // This is a server event - need to delete from database
      if (confirm(`Are you sure you want to delete "${event.title}"? This will permanently remove it from the database.`)) {
        // FIXED: Remove from local events immediately for visual feedback
        events[dateKey].splice(index, 1)
        if (events[dateKey].length === 0) {
          delete events[dateKey]
        }
        renderCalendar() // Update calendar immediately
          
        // Then submit to server
        const form = document.createElement('form')
        form.method = 'POST'
        form.style.display = 'none'
          
        // Add action input
        const actionInput = document.createElement('input')
        actionInput.type = 'hidden'
        actionInput.name = 'action'
        actionInput.value = 'delete_event'
        form.appendChild(actionInput)
          
        // Add event ID input
        const eventIdInput = document.createElement('input')
        eventIdInput.type = 'hidden'
        eventIdInput.name = 'event_id'
        eventIdInput.value = eventId
        form.appendChild(eventIdInput)
          
        // Add form to document and submit
        document.body.appendChild(form)
        form.submit()
          
        return true
      }
    } else {
      // This is a local event - delete from localStorage only
      if (confirm(`Are you sure you want to delete "${event.title}"?`)) {
        events[dateKey].splice(index, 1)

        if (events[dateKey].length === 0) {
          delete events[dateKey]
        }

        localStorage.setItem("calendarEvents", JSON.stringify(events))
        renderCalendar()
        return true
      }
    }
  }
  return false
}

/* NEW JavaScript: server-side deletion with confirmation
function deleteEvent(dateKey, index) {
  if (events[dateKey] && events[dateKey][index]) {
    const event = events[dateKey][index];
    const eventId = event.id;

    if (eventId && !eventId.toString().startsWith("local_")) {
      if (confirm(`Are you sure you want to delete "${event.title}"?`)) {
        const form = document.createElement("form");
        form.method = "POST";
        form.style.display = "none";
        form.innerHTML = `
          <input type="hidden" name="action" value="delete_event">
          <input type="hidden" name="event_id" value="${eventId}">
        `;
        document.body.appendChild(form);
        form.submit();
        return true;
      }
    }
  }
  return false;
}
*/

  // Time slot selection handling
  const timeSlots = document.querySelectorAll(".time-slot")
  timeSlots.forEach((slot) => {
    slot.addEventListener("click", function () {
      timeSlots.forEach((s) => s.classList.remove("selected"))
      this.classList.add("selected")
    })
  })

  // Event listeners for month navigation
  prevMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    renderCalendar()
  })

  nextMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    renderCalendar()
  })

  // Event listener for year display click
  yearDisplay.addEventListener("click", () => {
    populateYearGrid()
    yearPopup.classList.add("active")
  })

  // Event listener for close popup button
  closeYearPopup.addEventListener("click", () => {
    yearPopup.classList.remove("active")
  })

  // Close popup when clicking outside
  yearPopup.addEventListener("click", (e) => {
    if (e.target === yearPopup) {
      yearPopup.classList.remove("active")
    }
  })

  // Event listener for add event button
  addEventBtn.addEventListener("click", () => {
    addEventMode = !addEventMode
    document.getElementById("event-action").value = "add_event"
    addEventBtn.classList.toggle("active")

    // Disable link mode if add mode is activated
    if (addEventMode && linkEventMode) {
      linkEventMode = false
      linkEventBtn.classList.remove("active")
      calendar.classList.remove("link-mode")
      resetBookingForm()
    }
  })

// Link events for future months
function linkFutureEvent(dateKey, index) {
  // Split dateKey to extract year, month, day
  const [year, month, day] = dateKey.split("-").map(Number);

  // Update the currentDate to the correct month/year
  currentDate.setFullYear(year);
  currentDate.setMonth(month - 1);

  // Re-render the calendar so the day and event show
  renderCalendar();

  // Slight delay to allow DOM to update
  setTimeout(() => {
    populateBookingForm(dateKey, index);
  }, 100);
}


  // Event listener for link event button
  linkEventBtn.addEventListener("click", () => {
    linkEventMode = !linkEventMode
    linkEventBtn.classList.toggle("active")
    calendar.classList.toggle("link-mode")

    // Disable add mode if link mode is activated
    if (linkEventMode && addEventMode) {
      addEventMode = false
      addEventBtn.classList.remove("active")
    }

    if (linkEventMode) {
      alert("Link Event mode activated! Click on any event to populate the booking form.")
      resetBookingForm() // Reset form when entering link mode
    } else {
      resetBookingForm() // Reset form when exiting link mode
    }
  })

  // Event listener for close event popup button
  closeEventPopup.addEventListener("click", () => {
    eventPopup.classList.remove("active")
    selectedDate = null
  })

  // Close event popup when clicking outside
  eventPopup.addEventListener("click", (e) => {
    if (e.target === eventPopup) {
      eventPopup.classList.remove("active")
      selectedDate = null
    }
  })

  // Event listener for save event button
  saveEventBtn.addEventListener("click", () => {
    if (!selectedDate) return

    document.getElementById("event-date").value = `${selectedDate.year}-${selectedDate.month}-${selectedDate.day}`

    const title = document.getElementById("event-title").value
    const time = document.getElementById("event-time-select").value
    const description = document.getElementById("event-description").value
    const eventId = document.getElementById("event-id").value

    document.querySelectorAll(".error-message").forEach((el) => {
      el.style.display = "none"
    })

    let isValid = true

    if (title.trim() === "") {
      document.getElementById("title-error").style.display = "block"
      isValid = false
    }

    if (time === "") {
      document.getElementById("time-error").style.display = "block"
      isValid = false
    }

    if (description.trim() === "") {
      document.getElementById("description-error").style.display = "block"
      isValid = false
    }

    if (!isValid) return

    if (eventId && selectedEvent) {
      const success = updateEvent(selectedEvent.dateKey, selectedEvent.index, title, time, description)

      if (success) {
        eventPopup.classList.remove("active")
        selectedEvent = null
      }
    } else if (selectedDate) {
      const success = addEvent(selectedDate.day, selectedDate.month, selectedDate.year, title, time, description)

      if (success) {
        eventPopup.classList.remove("active")
        addEventMode = false
        addEventBtn.classList.remove("active")
        selectedDate = null
      }
    }
  })

  // Event listener for delete event button
  deleteEventBtn.addEventListener("click", () => {
    if (selectedEvent && confirm("Are you sure you want to delete this event?")) {
      const success = deleteEvent(selectedEvent.dateKey, selectedEvent.index)

      if (success) {
        eventPopup.classList.remove("active")
        selectedEvent = null
      }
    }
  })

  // Event listener for close details popup button
  closeDetailsPopup.addEventListener("click", () => {
    eventDetailsPopup.classList.remove("active")
    selectedEvent = null
  })

  // Close details popup when clicking outside
  eventDetailsPopup.addEventListener("click", (e) => {
    if (e.target === eventDetailsPopup) {
      eventDetailsPopup.classList.remove("active")
      selectedEvent = null
    }
  })

  // Event listener for edit event button in details popup
  editEventDetailsBtn.addEventListener("click", () => {
    if (selectedEvent) {
      document.getElementById("event-date").value = selectedEvent.dateKey
      const event = events[selectedEvent.dateKey][selectedEvent.index]
      document.getElementById("event-action").value = "edit-event"
      document.getElementById("event-id").value = event.time
      eventDetailsPopup.classList.remove("active")

      document.getElementById("event-popup-title").textContent = "Edit Event"
      document.getElementById("event-title").value = event.title
      document.getElementById("event-time-select").value = event.time || ""
      document.getElementById("event-description").value = event.description || ""

      deleteEventBtn.style.display = "block"
      populateTimeSlots()
      eventPopup.classList.add("active")
    }
  })

  // Event listener for close details button
  closeDetailsBtn.addEventListener("click", () => {
    eventDetailsPopup.classList.remove("active")
    selectedEvent = null
  })

  // FIXED: Handle booking form submission with proper linked event logic
  const bookingButton = document.querySelector(".book-appointment")
  if (bookingButton) {
    bookingButton.addEventListener("click", (e) => {
      e.preventDefault()

      // FIRST: Check if we're in linked mode (updating an existing event)
      if (linkedEventId && linkedEventData) {
        console.log("Processing linked event update...")

        // Validate required fields for linked event update
        const toArea = document.getElementById("to-area").value
        const toStreet = document.getElementById("to-street").value
        const fromArea = document.getElementById("from-area").value
        const fromStreet = document.getElementById("from-street").value
        const service = document.getElementById("service").value

        if (!toArea || !toStreet || !fromArea || !fromStreet || !service) {
          alert("Please fill in all required fields to update the event.")
          return
        }

        // For linked events, we already have the date and time from the event
        // No need to validate time slot selection or date selection
        console.log("Updating linked event:", {
          eventId: linkedEventId,
          date: document.getElementById("booking-date").value,
          time: document.getElementById("booking-time").value,
          to: { area: toArea, street: toStreet, info: document.getElementById("to-info").value },
          from: { area: fromArea, street: fromStreet, info: document.getElementById("from-info").value },
          service: service,
        })

        // Submit the form to update the existing appointment
        document.getElementById("booking-form").submit()
        return
      }

      // SECOND: Handle new booking logic (only if NOT in linked mode)
      console.log("Processing new booking...")

      // Check if we have a selected date (either from calendar selection or today's default)
      if (!selectedDate) {
        alert("Please select a date on the calendar")
        return
      }

      // Get selected time from time slots - ONLY required for new bookings
      const selectedTime = document.querySelector(".time-slot.selected")
      const selectedTimeValue = selectedTime ? selectedTime.textContent : null

      // Validate time selection for new bookings
      if (!selectedTimeValue) {
        alert("Please select a time slot")
        return
      }

      // Use the stored selectedDate information
      const day = selectedDate.day
      const currentMonthNumber = selectedDate.month
      const year = selectedDate.year
      const dateKey = `${year}-${currentMonthNumber}-${day}`

      // Format date for display
      const selectedDateStr = `${getMonthName(currentMonthNumber)} ${day}, ${year}`

      // Validate required booking fields
      const toArea = document.getElementById("to-area").value
      const toStreet = document.getElementById("to-street").value
      const fromArea = document.getElementById("from-area").value
      const fromStreet = document.getElementById("from-street").value
      const service = document.getElementById("service").value

      if (!toArea || !toStreet || !fromArea || !fromStreet || !service) {
        alert("Please fill in all required fields.")
        return
      }

      if (isTimeWithinTwoHours(dateKey, selectedTimeValue)) {
        alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
        return
      }

      console.log("New booking submitted:", {
        date: selectedDateStr,
        time: selectedTimeValue,
        to: {
          area: toArea,
          street: toStreet,
          info: document.getElementById("to-info").value,
        },
        from: {
          area: fromArea,
          street: fromStreet,
          info: document.getElementById("from-info").value,
        },
        service: service,
      })

      // Set the booking date and time in the form before submission
      document.getElementById("booking-date").value = selectedDateStr
      document.getElementById("booking-time").value = selectedTimeValue

      // Submit the form
      document.getElementById("booking-form").submit()
    })
  }

  // Populate time slots and render calendar
  populateTimeSlots()
  renderCalendar()
})
