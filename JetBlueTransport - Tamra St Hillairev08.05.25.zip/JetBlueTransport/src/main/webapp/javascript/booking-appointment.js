document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality from J-code
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.classList.add("hovered")
    })

    item.addEventListener("mouseleave", () => {
      item.classList.remove("hovered")
    })

    item.addEventListener("click", () => {
      // Remove active class from all items
      document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"))
      // Add active class to the clicked item
      item.classList.add("active")
    })
  })

  // Original calendar functionality
  const monthDisplay = document.getElementById("month-display")
  const calendarDays = document.getElementById("calendar-days")
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")

  // Set initial date to January 2025 to match the image
  const currentDate = new Date(2025, 0, 1) // January is 0

  // Month names
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Function to render the calendar
  function renderCalendar() {
    // Update month and year display
    monthDisplay.textContent = months[currentDate.getMonth()]
    document.querySelector(".year-display").textContent = currentDate.getFullYear()

    // Clear previous days
    calendarDays.innerHTML = ""

    // Get first day of month and last day of month
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    // Get the day of the week for the first day (0 is Sunday, 1 is Monday, etc.)
    // Adjust to make Monday the first day (0)
    let firstDayIndex = firstDay.getDay() - 1
    if (firstDayIndex < 0) firstDayIndex = 6 // Sunday becomes 6

    // Get the number of days in the previous month
    const prevLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
    const prevDaysCount = prevLastDay.getDate()

    // Get the number of days in the current month
    const daysInMonth = lastDay.getDate()

    // Calculate total cells needed (previous month days + current month days + next month days)
    const totalCells = Math.ceil((firstDayIndex + daysInMonth) / 7) * 7

    // Render days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${prevDaysCount - i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days from next month
    const remainingCells = totalCells - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= remainingCells; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }
  }

  // Time slot selection handling
  const timeSlots = document.querySelectorAll(".time-slot")
  timeSlots.forEach((slot) => {
    slot.addEventListener("click", function () {
      // Remove selected class from all slots
      timeSlots.forEach((s) => s.classList.remove("selected"))
      // Add selected class to clicked slot
      this.classList.add("selected")
    })
  })

  // Event listeners for month navigation
  prevMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    renderCalendar()
  })

  nextMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    renderCalendar()
  })

  // Initial render
  renderCalendar()

  // Handle booking form submission
  const bookingButton = document.querySelector(".book-appointment")
  if (bookingButton) {
    bookingButton.addEventListener("click", (e) => {
      e.preventDefault()

      // Get selected time slot
      const selectedTime = document.querySelector(".time-slot.selected")
      const selectedTimeValue = selectedTime ? selectedTime.textContent : null

      // Get selected date from calendar (if implemented)
      const selectedDate = currentDate.toLocaleDateString()

      // You can add validation and submission logic here
      console.log("Booking submitted:", {
        date: selectedDate,
        time: selectedTimeValue,
        to: {
          area: "East",
          street: "#12 Lane, Arthia",
          info: "By the big tree, passed the red abandoned house on the right",
        },
        from: {
          area: "South",
          street: "#34 Prakash Street, Delhi",
          info: "Near the police station, by the green shed",
        },
        service: document.querySelector(".service-section input").value,
      })
    })
  }
})

