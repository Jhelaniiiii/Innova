document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.classList.add("hovered")
    })

    item.addEventListener("mouseleave", () => {
      item.classList.remove("hovered")
    })

    item.addEventListener("click", () => {
      // Remove active class from all items
      document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"))
      // Add active class to the clicked item
      item.classList.add("active")
    })
  })

  // Calendar functionality
  const monthDisplay = document.getElementById("month-display")
  const yearDisplay = document.getElementById("year-display")
  const calendarDays = document.getElementById("calendar-days")
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")
  const yearPopup = document.getElementById("year-popup")
  const yearGrid = document.getElementById("year-grid")
  const closeYearPopup = document.getElementById("close-year-popup")
  const addEventBtn = document.getElementById("add-event-btn")
  const eventPopup = document.getElementById("event-popup")
  const closeEventPopup = document.getElementById("close-event-popup")
  const saveEventBtn = document.getElementById("save-event")
  const deleteEventBtn = document.getElementById("delete-event")
  const eventDetailsPopup = document.getElementById("event-details-popup")
  const closeDetailsPopup = document.getElementById("close-details-popup")
  const editEventDetailsBtn = document.getElementById("edit-event")
  const closeDetailsBtn = document.getElementById("close-details")

  // Set initial date to current date
  const currentDate = new Date()
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Month mapping and helper functions
  const monthMap = {
    "01": "January",
    "02": "February",
    "03": "March",
    "04": "April",
    "05": "May",
    "06": "June",
    "07": "July",
    "08": "August",
    "09": "September",
    "10": "October",
    "11": "November",
    "12": "December"
  }

  function getMonthNumber(monthIndex) {
    return (monthIndex + 1).toString().padStart(2, '0')
  }

  function getMonthName(monthNumber) {
    return monthMap[monthNumber] || monthMap[getMonthNumber(currentDate.getMonth())]
  }

  // Set range of years to display in the popup (current year -5 to +10)
  const currentYear = new Date().getFullYear()
  const startYear = currentYear - 0
  const endYear = currentYear + 10

  // Store events
  //const events = {}

  // Track if add event mode is active
  let addEventMode = false
  let selectedDate = null
  let selectedEvent = null

  // Maximum appointments per day
  const MAX_APPOINTMENTS_PER_DAY = 2

  // Function to check if a date is in the past
  function isPastDate(year, month, day) {
    const date = new Date(year, month - 1, day)
    date.setHours(0, 0, 0, 0)
    return date < today
  }

  // Function to check if a date has reached maximum appointments
  function isDateFull(year, month, day) {
    const dateKey = `${year}-${month}-${day}`
    return events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY
  }

  // Function to parse time string to hours and minutes
  function parseTimeString(timeStr) {
    if (!timeStr) return null

    // Extract hours, minutes, and AM/PM
    const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i)
    if (!match) return null

    let hours = Number.parseInt(match[1])
    const minutes = Number.parseInt(match[2])
    const ampm = match[3].toUpperCase()

    // Convert to 24-hour format
    if (ampm === "PM" && hours < 12) hours += 12
    if (ampm === "AM" && hours === 12) hours = 0

    return { hours, minutes }
  }

  // Function to check if a time is within 2 hours of existing appointments
  function isTimeWithinTwoHours(dateKey, timeStr) {
    if (!events[dateKey] || events[dateKey].length === 0) return false

    const newTime = parseTimeString(timeStr)
    if (!newTime) return false

    const newTimeMinutes = newTime.hours * 60 + newTime.minutes

    for (const event of events[dateKey]) {
      const existingTime = parseTimeString(event.time)
      if (!existingTime) continue

      const existingTimeMinutes = existingTime.hours * 60 + existingTime.minutes
      const diffMinutes = Math.abs(newTimeMinutes - existingTimeMinutes)

      if (diffMinutes < 120) {
        return true
      }
    }

    return false
  }

  // Function to populate time slots in the event form
  function populateTimeSlots() {
    const timeSelect = document.getElementById("event-time-select")
    if (!timeSelect) return

    timeSelect.innerHTML = '<option value="">Select a time</option>'

    const dateKey = selectedDate ? `${selectedDate.year}-${selectedDate.month}-${selectedDate.day}` : null

    for (let hour = 9; hour <= 16; hour++) {
      const hourStr = hour > 12 ? hour - 12 : hour
      const ampm = hour >= 12 ? "PM" : "AM"

      const fullHourTimeStr = `${hourStr}:00 ${ampm}`
      const fullHourBlocked = dateKey && isTimeWithinTwoHours(dateKey, fullHourTimeStr)

      if (!fullHourBlocked || (selectedEvent && events[selectedEvent.dateKey][selectedEvent.index].time === fullHourTimeStr)) {
        const fullHourOption = document.createElement("option")
        fullHourOption.value = fullHourTimeStr
        fullHourOption.textContent = fullHourTimeStr
        timeSelect.appendChild(fullHourOption)
      }

      if (hour < 16) {
        const halfHourTimeStr = `${hourStr}:30 ${ampm}`
        const halfHourBlocked = dateKey && isTimeWithinTwoHours(dateKey, halfHourTimeStr)

        if (!halfHourBlocked || (selectedEvent && events[selectedEvent.dateKey][selectedEvent.index].time === halfHourTimeStr)) {
          const halfHourOption = document.createElement("option")
          halfHourOption.value = halfHourTimeStr
          halfHourOption.textContent = halfHourTimeStr
          timeSelect.appendChild(halfHourOption)
        }
      }
    }

    if (timeSelect.options.length === 1) {
      const noSlotsOption = document.createElement("option")
      noSlotsOption.value = ""
      noSlotsOption.textContent = "No available times (all within 2 hours of existing appointments)"
      noSlotsOption.disabled = true
      timeSelect.appendChild(noSlotsOption)
    }
  }

  // Function to render the calendar
  function renderCalendar() {
    const currentMonthNumber = getMonthNumber(currentDate.getMonth())
    monthDisplay.textContent = getMonthName(currentMonthNumber)
    yearDisplay.textContent = currentDate.getFullYear()

    calendarDays.innerHTML = ""

    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    let firstDayIndex = firstDay.getDay() - 1
    if (firstDayIndex < 0) firstDayIndex = 6

    const prevLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
    const prevDaysCount = prevLastDay.getDate()
    const daysInMonth = lastDay.getDate()
    const totalCells = Math.ceil((firstDayIndex + daysInMonth) / 7) * 7

    // Render days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${prevDaysCount - i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day")

      const isToday =
        i === today.getDate() &&
        currentDate.getMonth() === today.getMonth() &&
        currentDate.getFullYear() === today.getFullYear()

      if (isToday) {
        dayElement.classList.add("today")
      }

      const isPast = isPastDate(currentDate.getFullYear(), currentDate.getMonth() + 1, i)
      if (isPast) {
        dayElement.classList.add("past-date")
      }

      const dayNumberElement = document.createElement("div")
      dayNumberElement.classList.add("day-number")
      dayNumberElement.textContent = i
      dayElement.appendChild(dayNumberElement)

      const currentMonthNumber = getMonthNumber(currentDate.getMonth())
      dayElement.dataset.day = i
      dayElement.dataset.month = currentMonthNumber
      dayElement.dataset.year = currentDate.getFullYear()

      const dateKey = `${currentDate.getFullYear()}-${currentMonthNumber}-${i}`
      if (events[dateKey]) {
        events[dateKey].forEach((event, index) => {
          const eventElement = document.createElement("div")
          eventElement.classList.add("event")
          eventElement.dataset.index = index

          const titleElement = document.createElement("div")
          titleElement.textContent = event.title
          eventElement.appendChild(titleElement)

          if (event.time) {
            const timeElement = document.createElement("div")
            timeElement.classList.add("event-time")
            timeElement.textContent = event.time
            eventElement.appendChild(timeElement)
          }

          eventElement.addEventListener("click", (e) => {
            e.stopPropagation()
            showEventDetails(dateKey, index)
          })

          dayElement.appendChild(eventElement)
        })

        if (events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
          dayElement.classList.add("full")
        }
      }

      if (!isPast && !isDateFull(currentDate.getFullYear(), currentMonthNumber, i)) {
        dayElement.addEventListener("click", () => {
          if (addEventMode) {
            selectedDate = {
              day: i,
              month: currentMonthNumber,
              year: currentDate.getFullYear(),
            }

            document.getElementById("event-popup-title").textContent = "Add New Event"
            document.getElementById("event-title").value = ""
            document.getElementById("event-time-select").value = ""
            document.getElementById("event-description").value = ""
            document.getElementById("event-id").value = ""

            deleteEventBtn.style.display = "none"
            populateTimeSlots()
            eventPopup.classList.add("active")
          } else {
            document.querySelectorAll(".day").forEach((day) => {
              day.classList.remove("selected")
            })
            dayElement.classList.add("selected")
          }
        })
      }

      if (isToday && !isDateFull(currentDate.getFullYear(), currentMonthNumber, i)) {
        dayElement.classList.add("selected")
      }

      calendarDays.appendChild(dayElement)
    }

    // Render days from next month
    for (let i = 1; i <= totalCells - (firstDayIndex + daysInMonth); i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }
  }

  // Function to show event details
  function showEventDetails(dateKey, index) {
    if (events[dateKey] && events[dateKey][index]) {
      const event = events[dateKey][index]
      selectedEvent = { dateKey, index }

      const [year, month, day] = dateKey.split("-")
      const formattedDate = `${getMonthName(month)} ${day}, ${year}`

      document.getElementById("detail-title").textContent = event.title
      document.getElementById("detail-date").textContent = formattedDate
      document.getElementById("detail-time").textContent = event.time || "Not specified"
      document.getElementById("detail-description").textContent = event.description || "No description"

      eventDetailsPopup.classList.add("active")
    }
  }

  // Function to populate the year selection popup
  function populateYearGrid() {
    yearGrid.innerHTML = ""

    for (let year = startYear; year <= endYear; year++) {
      const yearButton = document.createElement("button")
      yearButton.classList.add("year-option")
      yearButton.textContent = year

      if (year === currentDate.getFullYear()) {
        yearButton.classList.add("selected")
      }

      yearButton.addEventListener("click", () => {
        currentDate.setFullYear(year)
        renderCalendar()
        yearPopup.classList.remove("active")
      })

      yearGrid.appendChild(yearButton)
    }
  }

  // Function to add a new event
  function addEvent(day, month, year, title, time, description) {
    const dateKey = `${year}-${month}-${day}`

    if (events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
      alert(`Sorry, this day already has the maximum of ${MAX_APPOINTMENTS_PER_DAY} appointments.`)
      return false
    }

    if (isTimeWithinTwoHours(dateKey, time)) {
      alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
      return false
    }

    if (!events[dateKey]) {
      events[dateKey] = []
    }

    events[dateKey].push({
      title,
      time,
      description,
    })

    renderCalendar()
    return true
  }

  // Function to update an existing event
  function updateEvent(dateKey, index, title, time, description) {
    if (events[dateKey] && events[dateKey][index]) {
      const originalTime = events[dateKey][index].time
      const tempEvent = events[dateKey].splice(index, 1)[0]

      if (time !== originalTime && isTimeWithinTwoHours(dateKey, time)) {
        events[dateKey].splice(index, 0, tempEvent)
        alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
        return false
      }

      events[dateKey].splice(index, 0, {
        title,
        time,
        description,
      })

      renderCalendar()
      return true
    }
    return false
  }

  // Function to delete an event
  function deleteEvent(dateKey, index) {
    if (events[dateKey] && events[dateKey][index]) {
      events[dateKey].splice(index, 1)

      if (events[dateKey].length === 0) {
        delete events[dateKey]
      }

      renderCalendar()
      return true
    }
    return false
  }

  // Time slot selection handling
  const timeSlots = document.querySelectorAll(".time-slot")
  timeSlots.forEach((slot) => {
    slot.addEventListener("click", function () {
      timeSlots.forEach((s) => s.classList.remove("selected"))
      this.classList.add("selected")
    })
  })

  // Event listeners for month navigation
  prevMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    renderCalendar()
  })

  nextMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    renderCalendar()
  })

  // Event listener for year display click
  yearDisplay.addEventListener("click", () => {
    populateYearGrid()
    yearPopup.classList.add("active")
  })

  // Event listener for close popup button
  closeYearPopup.addEventListener("click", () => {
    yearPopup.classList.remove("active")
  })

  // Close popup when clicking outside
  yearPopup.addEventListener("click", (e) => {
    if (e.target === yearPopup) {
      yearPopup.classList.remove("active")
    }
  })

  // Event listener for add event button
  addEventBtn.addEventListener("click", () => {
    addEventMode = !addEventMode
    document.getElementById("event-action").value = "add_event"
    addEventBtn.classList.toggle("active")
  })

  // Event listener for close event popup button
  closeEventPopup.addEventListener("click", () => {
    eventPopup.classList.remove("active")
    selectedDate = null
  })

  // Close event popup when clicking outside
  eventPopup.addEventListener("click", (e) => {
    if (e.target === eventPopup) {
      eventPopup.classList.remove("active")
      selectedDate = null
    }
  })

  // Event listener for save event button
  saveEventBtn.addEventListener("click", () => {
    document.getElementById("event-date").value = `${selectedDate.year}-${selectedDate.month}-${selectedDate.day}`
    
    const title = document.getElementById("event-title").value
    const time = document.getElementById("event-time-select").value
    const description = document.getElementById("event-description").value
    const eventId = document.getElementById("event-id").value

    document.querySelectorAll(".error-message").forEach((el) => {
      el.style.display = "none"
    })

    let isValid = true

    if (title.trim() === "") {
      document.getElementById("title-error").style.display = "block"
      isValid = false
    }

    if (time === "") {
      document.getElementById("time-error").style.display = "block"
      isValid = false
    }

    if (description.trim() === "") {
      document.getElementById("description-error").style.display = "block"
      isValid = false
    }

    if (!isValid) return

    if (eventId && selectedEvent) {
      const success = updateEvent(selectedEvent.dateKey, selectedEvent.index, title, time, description)

      if (success) {
        eventPopup.classList.remove("active")
        selectedEvent = null
      }
    } else if (selectedDate) {
      const success = addEvent(selectedDate.day, selectedDate.month, selectedDate.year, title, time, description)

      if (success) {
        eventPopup.classList.remove("active")
        addEventMode = false
        addEventBtn.classList.remove("active")
        selectedDate = null
      }
    }
  })

  // Event listener for delete event button
  deleteEventBtn.addEventListener("click", () => {
    if (selectedEvent && confirm("Are you sure you want to delete this event?")) {
      const success = deleteEvent(selectedEvent.dateKey, selectedEvent.index)

      if (success) {
        eventPopup.classList.remove("active")
        selectedEvent = null
      }
    }
  })

  // Event listener for close details popup button
  closeDetailsPopup.addEventListener("click", () => {
    eventDetailsPopup.classList.remove("active")
    selectedEvent = null
  })

  // Close details popup when clicking outside
  eventDetailsPopup.addEventListener("click", (e) => {
    if (e.target === eventDetailsPopup) {
      eventDetailsPopup.classList.remove("active")
      selectedEvent = null
    }
  })

  // Event listener for edit event button in details popup
  editEventDetailsBtn.addEventListener("click", () => {
    if (selectedEvent) {
	  document.getElementById("event-date").value = selectedEvent.dateKey
      const event = events[selectedEvent.dateKey][selectedEvent.index]
      document.getElementById("event-action").value = "edit-event"
      document.getElementById("event-id").value = event.time
      eventDetailsPopup.classList.remove("active")

      document.getElementById("event-popup-title").textContent = "Edit Event"
      document.getElementById("event-title").value = event.title
      document.getElementById("event-time-select").value = event.time || ""
      document.getElementById("event-description").value = event.description || ""

      deleteEventBtn.style.display = "block"
      populateTimeSlots()
      eventPopup.classList.add("active")
    }
  })

  // Event listener for close details button
  closeDetailsBtn.addEventListener("click", () => {
    eventDetailsPopup.classList.remove("active")
    selectedEvent = null
  })

  // Populate time slots and render calendar
  populateTimeSlots()
  renderCalendar()

  // Handle booking form submission
  const bookingButton = document.querySelector(".book-appointment")
  if (bookingButton) {
    bookingButton.addEventListener("click", (e) => {
      e.preventDefault()

      const selectedTime = document.querySelector(".time-slot.selected")
      const selectedTimeValue = selectedTime ? selectedTime.textContent : null

      const selectedDay = document.querySelector(".day.selected")
      let selectedDayValue = null

      if (selectedDay) {
        const dayNumber = selectedDay.querySelector(".day-number")
        if (dayNumber) {
          selectedDayValue = dayNumber.textContent
        }
      }

      let selectedDateStr = "Not selected"
      if (selectedDayValue) {
        const currentMonthNumber = getMonthNumber(currentDate.getMonth())
        selectedDateStr = `${getMonthName(currentMonthNumber)} ${selectedDayValue}, ${currentDate.getFullYear()}`
      }

      if (selectedDayValue === null) {
        alert("Please select a date on the calendar")
        return
      }

      /*if (selectedTimeValue === null) {
        alert("Please select a time slot")
        return
      }*/

      const day = Number.parseInt(selectedDayValue)
      const currentMonthNumber = getMonthNumber(currentDate.getMonth())
      const dateKey = `${currentDate.getFullYear()}-${currentMonthNumber}-${day}`

      if (isTimeWithinTwoHours(dateKey, selectedTimeValue)) {
        alert("Sorry, you cannot schedule an appointment within 2 hours of an existing appointment.")
        return
      }

      console.log("Booking submitted:", {
        date: selectedDateStr,
        time: selectedTimeValue,
        to: {
          area: document.querySelector(".location-section:nth-child(1) .form-group:nth-child(1) input").value || "East",
          street: document.querySelector(".location-section:nth-child(1) .form-group:nth-child(2) input").value || "#12 Lane, Arthia",
          info: document.querySelector(".location-section:nth-child(1) .form-group.full-width input").value || "By the big tree, passed the red abandoned house on the right",
        },
        from: {
          area: document.querySelector(".location-section:nth-child(2) .form-group:nth-child(1) input").value || "South",
          street: document.querySelector(".location-section:nth-child(2) .form-group:nth-child(2) input").value || "#34 Prakash Street, Delhi",
          info: document.querySelector(".location-section:nth-child(2) .form-group.full-width input").value || "Near the police station, by the green shed",
        },
        service: document.querySelector(".service-section input").value,
      })

      const success = addEvent(
        day,
        currentMonthNumber,
        currentDate.getFullYear(),
        "Booking: " + selectedTimeValue,
        selectedTimeValue,
        "Transport booking"
      )

      if (success) {
        alert("Booking confirmed!")
      }
    })
  }
})