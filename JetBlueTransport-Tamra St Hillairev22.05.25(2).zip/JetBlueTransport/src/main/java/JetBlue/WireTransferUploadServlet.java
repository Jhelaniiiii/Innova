package JetBlue;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/customer/wire-transfer-upload")
@MultipartConfig(
    maxFileSize = 2097152,       // 2MB
    maxRequestSize = 4194304,    // 4MB
    fileSizeThreshold = 1048576  // 1MB
)
public class WireTransferUploadServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/customer/verify.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        if (email == null || email.isEmpty()) {
            session.setAttribute("error", "No active session found");
            response.sendRedirect(request.getContextPath() + "/customer/verify.jsp");
            return;
        }

        try {
            // Verify multipart request
            String contentType = request.getContentType();
            if (contentType == null || !contentType.toLowerCase().startsWith("multipart/form-data")) {
                session.setAttribute("error", "Invalid form data");
                response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
                return;
            }

            // Get file part
            Part filePart = request.getPart("receiptPicture");
            if (filePart == null || filePart.getSize() == 0) {
                session.setAttribute("error", "Please select a valid file");
                response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
                return;
            }

            // File validation
            String fileName = filePart.getSubmittedFileName();
            
            if (fileName == null || !fileName.matches("(?i).*\\.(jpg|jpeg|png|pdf)$")) {
                session.setAttribute("error", "Only JPG/JPEG/PNG/PDF files allowed");
                response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
                return;
            }

            if (filePart.getSize() > 2000000) {
                session.setAttribute("error", "File too large (max 2MB)");
                response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
                return;
            }

            // Process in memory
            try (Connection con = ConnectionProvider.getCon()) {
                if (con == null || con.isClosed()) {
                    session.setAttribute("error", "Database connection failed");
                    response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
                    return;
                }

                con.setAutoCommit(false);
                
                try (InputStream fileContent = filePart.getInputStream();
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    
                    byte[] data = new byte[16384];
                    int nRead;
                    while ((nRead = fileContent.read(data, 0, data.length)) != -1) {
                        buffer.write(data, 0, nRead);
                    }
                    buffer.flush();
                    
                    byte[] fileData = buffer.toByteArray();
                    
                    try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO wireTransfer (email, recite_pic) VALUES (?, ?)")) {
                        
                        ps.setString(1, email);
                        ps.setBytes(2, fileData);
                        
                        int rowsInserted = ps.executeUpdate();
                        if (rowsInserted > 0) {
                            session.setAttribute("success", "Receipt uploaded successfully!");
                        } else {
                            session.setAttribute("error", "Failed to upload receipt");
                        }
                        con.commit();
                    }
                } catch (SQLException e) {
                    if (con != null) {
                        try { con.rollback(); } catch (SQLException ex) {}
                    }
                    session.setAttribute("error", "Database error: " + e.getMessage());
                } finally {
                    if (con != null) {
                        try { con.setAutoCommit(true); } catch (SQLException e) {}
                    }
                }
            }
        } catch (Exception e) {
            session.setAttribute("error", "Upload failed: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/customer/officialwiretransfer.jsp");
    }
}