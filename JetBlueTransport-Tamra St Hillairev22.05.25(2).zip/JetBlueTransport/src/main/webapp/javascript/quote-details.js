document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const closeSidebar = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.add('active');
            overlay.classList.add('active');
        });
    }

    if (closeSidebar) {
        closeSidebar.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        });
    }

    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        });
    }

    // Modal functionality
    const modal = document.getElementById('confirmModal');
    const modalClose = document.getElementById('modalClose');
    const confirmAction = document.getElementById('confirmAction');
    const cancelAction = document.getElementById('cancelAction');
    const modalTitle = document.getElementById('modalTitle');
    const modalMessage = document.getElementById('modalMessage');

    // Approve and Reject buttons
    const approveButton = document.querySelector('.approve-btn');
    const rejectButton = document.querySelector('.reject-btn');

    // Function to show modal
    function showModal(title, message, confirmText, action) {
        modalTitle.textContent = title;
        modalMessage.textContent = message;
        confirmAction.textContent = confirmText;
        
        // Store the action function to be executed on confirm
        confirmAction.onclick = action;
        
        modal.style.display = 'flex';
    }

    // Function to hide modal
    function hideModal() {
        modal.style.display = 'none';
    }

    // Close modal when clicking the close button
    if (modalClose) {
        modalClose.addEventListener('click', hideModal);
    }

    // Close modal when clicking the cancel button
    if (cancelAction) {
        cancelAction.addEventListener('click', hideModal);
    }

    // Close modal when clicking outside the modal content
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            hideModal();
        }
    });

    // Function to handle approve action
    function approveQuote(id, name) {
        showModal(
            `Approve Quote from ${name}?`,
            'Once approved, the customer will be notified and the quote will be marked as approved.',
            `YES, APPROVE ${name.toUpperCase()}'S QUOTE`,
            function() {
                // Send AJAX request to approve the quote
                fetch(`approveQuote.jsp?id=${id}`, {
                    method: 'GET'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Redirect to quotes page or reload current page
                        window.location.href = 'quotes.jsp';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while processing your request.');
                })
                .finally(() => {
                    hideModal();
                });
            }
        );
    }

    // Function to handle reject action
    function rejectQuote(id, name) {
        showModal(
            `Reject Quote from ${name}?`,
            'Once rejected, the customer will be notified and the quote will be marked as rejected.',
            `YES, REJECT ${name.toUpperCase()}'S QUOTE`,
            function() {
                // Send AJAX request to reject the quote
                fetch(`rejectQuote.jsp?id=${id}`, {
                    method: 'GET'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Redirect to quotes page or reload current page
                        window.location.href = 'quotes.jsp';
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while processing your request.');
                })
                .finally(() => {
                    hideModal();
                });
            }
        );
    }

    // Add event listener to approve button
    if (approveButton) {
        approveButton.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            approveQuote(id, name);
        });
    }

    // Add event listener to reject button
    if (rejectButton) {
        rejectButton.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            rejectQuote(id, name);
        });
    }
});