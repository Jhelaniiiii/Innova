document.addEventListener("DOMContentLoaded", () => {
    // Navigation button functionality
    const navButtons = document.querySelectorAll(".nav-button")
  
    navButtons.forEach((button) => {
      button.addEventListener("click", () => {
        // Remove active class from all buttons
        navButtons.forEach((btn) => btn.classList.remove("active"))
        // Add active class to clicked button
        button.classList.add("active")
      })
    })
  
    // Logout button functionality
    const logoutButton = document.querySelector(".logout-button")
  
    logoutButton.addEventListener("click", () => {
      // In a real application, this would handle logout logic
      alert("Logging out...")
    })
  
    // Sort jobs by date
    const jobsList = document.querySelector(".jobs-list")
    const jobs = Array.from(jobsList.children)
  
    function sortJobs() {
      jobs.sort((a, b) => {
        const dateA = new Date(a.querySelector(".datetime").textContent + " " + a.querySelector(".time").textContent)
        const dateB = new Date(b.querySelector(".datetime").textContent + " " + b.querySelector(".time").textContent)
        return dateA - dateB
      })
  
      jobs.forEach((job) => {
        jobsList.appendChild(job)
      })
    }
  
    // Initial sort
    sortJobs()
  })
  
  