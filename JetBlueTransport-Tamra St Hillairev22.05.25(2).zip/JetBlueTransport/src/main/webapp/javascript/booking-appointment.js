document.addEventListener("DOMContentLoaded", () => {
  console.log("Document loaded and ready")

  // Navigation functionality
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.classList.add("hovered")
    })

    item.addEventListener("mouseleave", () => {
      item.classList.remove("hovered")
    })

    item.addEventListener("click", () => {
      document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"))
      item.classList.add("active")
    })
  })

  // Calendar elements
  const monthDisplay = document.getElementById("month-display")
  const yearDisplay = document.getElementById("year-display")
  const calendarDays = document.getElementById("calendar-days")
  const prevMonthBtn = document.getElementById("prev-month")
  const nextMonthBtn = document.getElementById("next-month")

  // Popup elements
  const yearPopup = document.getElementById("year-popup")
  const yearGrid = document.getElementById("year-grid")
  const closeYearPopup = document.getElementById("close-year-popup")
  const eventPopup = document.getElementById("event-popup")
  const closeEventPopup = document.getElementById("close-event-popup")
  const saveEventBtn = document.getElementById("save-event")
  const addEventBtn = document.getElementById("add-event-btn")

  // Form elements
  const eventTitleInput = document.getElementById("event-title")
  const eventTimeInput = document.getElementById("event-time")
  const eventDescriptionInput = document.getElementById("event-description")

  // Error message elements
  const titleError = document.getElementById("title-error")
  const timeError = document.getElementById("time-error")
  const descriptionError = document.getElementById("description-error")

  // Set initial date to current date
  const currentDate = new Date()
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  // Year range for year selector
  const currentYear = today.getFullYear()
  const startYear = currentYear - 5
  const endYear = currentYear + 10

  // Store events
  const events = {}

  // Track add event mode and selected date
  let addEventMode = false
  let selectedDate = null

  // Maximum appointments per day
  const MAX_APPOINTMENTS_PER_DAY = 2

  // Month names
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Check if a date is in the past
  function isPastDate(year, month, day) {
    const date = new Date(year, month, day)
    date.setHours(0, 0, 0, 0)
    return date < today
  }

  // Check if a date has reached maximum appointments
  function isDateFull(year, month, day) {
    const dateKey = `${year}-${month}-${day}`
    return events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY
  }

  // Validate form fields
  function validateFormFields() {
    let isValid = true

    // Reset error states
    eventTitleInput.classList.remove("error")
    eventTimeInput.classList.remove("error")
    eventDescriptionInput.classList.remove("error")
    titleError.classList.remove("visible")
    timeError.classList.remove("visible")
    descriptionError.classList.remove("visible")

    // Validate title
    if (!eventTitleInput.value.trim()) {
      eventTitleInput.classList.add("error")
      titleError.classList.add("visible")
      isValid = false
    }

    // Validate time
    if (!eventTimeInput.value) {
      eventTimeInput.classList.add("error")
      timeError.classList.add("visible")
      isValid = false
    }

    // Validate description
    if (!eventDescriptionInput.value.trim()) {
      eventDescriptionInput.classList.add("error")
      descriptionError.classList.add("visible")
      isValid = false
    }

    return isValid
  }

  // Render the calendar
  function renderCalendar() {
    console.log("Rendering calendar for:", currentDate.toDateString())

    // Update month and year display
    monthDisplay.textContent = months[currentDate.getMonth()]
    yearDisplay.textContent = currentDate.getFullYear()

    // Clear previous days
    calendarDays.innerHTML = ""

    // Get first day of month and last day of month
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    // Get the day of the week for the first day (0 is Sunday, 1 is Monday, etc.)
    // Adjust to make Monday the first day (0)
    let firstDayIndex = firstDay.getDay() - 1
    if (firstDayIndex < 0) firstDayIndex = 6 // Sunday becomes 6

    // Get the number of days in the previous month
    const prevLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0)
    const prevDaysCount = prevLastDay.getDate()

    // Get the number of days in the current month
    const daysInMonth = lastDay.getDate()

    // Calculate total cells needed
    const totalCells = Math.ceil((firstDayIndex + daysInMonth) / 7) * 7

    // Render days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${prevDaysCount - i}</div>`
      calendarDays.appendChild(dayElement)
    }

    // Render days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day")

      // Check if this day is today
      const isToday =
        i === today.getDate() &&
        currentDate.getMonth() === today.getMonth() &&
        currentDate.getFullYear() === today.getFullYear()

      if (isToday) {
        dayElement.classList.add("today")
      }

      // Check if this day is in the past
      const isPast = isPastDate(currentDate.getFullYear(), currentDate.getMonth(), i)
      if (isPast) {
        dayElement.classList.add("past-date")
      }

      // Create day number element
      const dayNumberElement = document.createElement("div")
      dayNumberElement.classList.add("day-number")
      dayNumberElement.textContent = i
      dayElement.appendChild(dayNumberElement)

      // Store date information as data attributes
      dayElement.dataset.day = i
      dayElement.dataset.month = currentDate.getMonth()
      dayElement.dataset.year = currentDate.getFullYear()

      // Check if there are events for this day and render them
      const dateKey = `${currentDate.getFullYear()}-${currentDate.getMonth()}-${i}`
      if (events[dateKey]) {
        events[dateKey].forEach((event) => {
          const eventElement = document.createElement("div")
          eventElement.classList.add("event")
          eventElement.textContent = event.title
          dayElement.appendChild(eventElement)
        })

        // Check if day has reached maximum appointments
        if (events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
          dayElement.classList.add("full")
        }
      }

      // Add click event to select a day only if it's not in the past and not full
      if (!isPast && !isDateFull(currentDate.getFullYear(), currentDate.getMonth(), i)) {
        dayElement.addEventListener("click", () => {
          if (addEventMode) {
            // If in add event mode, show event popup
            selectedDate = {
              day: i,
              month: currentDate.getMonth(),
              year: currentDate.getFullYear(),
            }

            console.log("Selected date for event:", selectedDate)

            // Show the event creation popup
            eventTitleInput.value = ""
            eventTimeInput.value = ""
            eventDescriptionInput.value = ""

            // Reset error states
            eventTitleInput.classList.remove("error")
            eventTimeInput.classList.remove("error")
            eventDescriptionInput.classList.remove("error")
            titleError.classList.remove("visible")
            timeError.classList.remove("visible")
            descriptionError.classList.remove("visible")

            // Make sure the popup is visible
            eventPopup.style.display = "flex"
            eventPopup.classList.add("active")

            console.log("Event popup should be visible now")
          } else {
            // Regular day selection
            document.querySelectorAll(".day").forEach((day) => {
              day.classList.remove("selected")
            })
            dayElement.classList.add("selected")
          }
        })
      }

      calendarDays.appendChild(dayElement)
    }

    // Render days from next month
    const remainingCells = totalCells - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= remainingCells; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("day", "inactive")
      dayElement.innerHTML = `<div class="day-number">${i}</div>`
      calendarDays.appendChild(dayElement)
    }
  }

  // Populate the year selection popup
  function populateYearGrid() {
    yearGrid.innerHTML = ""

    for (let year = startYear; year <= endYear; year++) {
      const yearButton = document.createElement("button")
      yearButton.classList.add("year-option")
      yearButton.textContent = year

      if (year === currentDate.getFullYear()) {
        yearButton.classList.add("selected")
      }

      yearButton.addEventListener("click", () => {
        currentDate.setFullYear(year)
        renderCalendar()
        yearPopup.classList.remove("active")
        yearPopup.style.display = "none"
      })

      yearGrid.appendChild(yearButton)
    }
  }

  // Add a new event
  function addEvent(day, month, year, title, time, description) {
    console.log("Adding event:", { day, month, year, title, time, description })

    const dateKey = `${year}-${month}-${day}`

    if (events[dateKey] && events[dateKey].length >= MAX_APPOINTMENTS_PER_DAY) {
      alert(`Sorry, this day already has the maximum of ${MAX_APPOINTMENTS_PER_DAY} appointments.`)
      return false
    }

    if (!events[dateKey]) {
      events[dateKey] = []
    }

    events[dateKey].push({
      title,
      time,
      description,
    })

    renderCalendar()
    return true
  }

  // Month navigation
  prevMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    renderCalendar()
  })

  nextMonthBtn.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    renderCalendar()
  })

  // Year selection
  yearDisplay.addEventListener("click", () => {
    populateYearGrid()
    yearPopup.style.display = "flex"
    yearPopup.classList.add("active")
  })

  closeYearPopup.addEventListener("click", () => {
    yearPopup.classList.remove("active")
    yearPopup.style.display = "none"
  })

  yearPopup.addEventListener("click", (e) => {
    if (e.target === yearPopup) {
      yearPopup.classList.remove("active")
      yearPopup.style.display = "none"
    }
  })

  // Add event mode toggle
  addEventBtn.addEventListener("click", () => {
    console.log("Add event button clicked")
    addEventMode = !addEventMode

    if (addEventMode) {
      addEventBtn.classList.add("active")
      console.log("Add event mode activated")
    } else {
      addEventBtn.classList.remove("active")
      console.log("Add event mode deactivated")
    }
  })

  // Event popup handling
  closeEventPopup.addEventListener("click", () => {
    eventPopup.classList.remove("active")
    eventPopup.style.display = "none"
    selectedDate = null
  })

  eventPopup.addEventListener("click", (e) => {
    if (e.target === eventPopup) {
      eventPopup.classList.remove("active")
      eventPopup.style.display = "none"
      selectedDate = null
    }
  })

  // Input field validation on blur
  eventTitleInput.addEventListener("blur", () => {
    if (!eventTitleInput.value.trim()) {
      eventTitleInput.classList.add("error")
      titleError.classList.add("visible")
    } else {
      eventTitleInput.classList.remove("error")
      titleError.classList.remove("visible")
    }
  })

  eventTimeInput.addEventListener("blur", () => {
    if (!eventTimeInput.value) {
      eventTimeInput.classList.add("error")
      timeError.classList.add("visible")
    } else {
      eventTimeInput.classList.remove("error")
      timeError.classList.remove("visible")
    }
  })

  eventDescriptionInput.addEventListener("blur", () => {
    if (!eventDescriptionInput.value.trim()) {
      eventDescriptionInput.classList.add("error")
      descriptionError.classList.add("visible")
    } else {
      eventDescriptionInput.classList.remove("error")
      descriptionError.classList.remove("visible")
    }
  })

  // Save event
  saveEventBtn.addEventListener("click", () => {
    console.log("Save event button clicked")

    if (selectedDate) {
      // Validate all fields
      if (validateFormFields()) {
        const title = eventTitleInput.value
        const time = eventTimeInput.value
        const description = eventDescriptionInput.value

        const success = addEvent(selectedDate.day, selectedDate.month, selectedDate.year, title, time, description)

        if (success) {
          eventPopup.classList.remove("active")
          eventPopup.style.display = "none"
          addEventMode = false
          addEventBtn.classList.remove("active")
          selectedDate = null
          console.log("Event saved successfully")
        }
      } else {
        console.log("Form validation failed")
      }
    } else {
      console.error("No date selected for event")
    }
  })

  // Booking form submission
  const bookingButton = document.querySelector(".book-appointment")
  if (bookingButton) {
    bookingButton.addEventListener("click", (e) => {
      e.preventDefault()

      // Get selected date from calendar
      const selectedDay = document.querySelector(".day.selected .day-number")
      const selectedDayValue = selectedDay ? selectedDay.textContent : null

      let selectedDateStr = "Not selected"
      if (selectedDayValue) {
        selectedDateStr = `${months[currentDate.getMonth()]} ${selectedDayValue}, ${currentDate.getFullYear()}`
      }

      // Check if a date is selected
      if (selectedDayValue === null) {
        alert("Please select a date on the calendar")
        return
      }

      console.log("Booking submitted:", {
        date: selectedDateStr,
        to: {
          area: document.querySelector(".location-section:nth-child(1) .form-group:nth-child(1) input").value || "East",
          street:
            document.querySelector(".location-section:nth-child(1) .form-group:nth-child(2) input").value ||
            "#12 Lane, Arthia",
          info:
            document.querySelector(".location-section:nth-child(1) .form-group.full-width input").value ||
            "By the big tree, passed the red abandoned house on the right",
        },
        from: {
          area:
            document.querySelector(".location-section:nth-child(2) .form-group:nth-child(1) input").value || "South",
          street:
            document.querySelector(".location-section:nth-child(2) .form-group:nth-child(2) input").value ||
            "#34 Prakash Street, Delhi",
          info:
            document.querySelector(".location-section:nth-child(2) .form-group.full-width input").value ||
            "Near the police station, by the green shed",
        },
        service: document.querySelector(".service-section input").value,
      })

      // Add the booking as an event
      const day = Number.parseInt(selectedDayValue)
      const currentTime = new Date()
      const timeStr = `${currentTime.getHours()}:${currentTime.getMinutes()}`

      const success = addEvent(
        day,
        currentDate.getMonth(),
        currentDate.getFullYear(),
        "Booking",
        timeStr,
        "Transport booking"
      )

      if (success) {
        alert("Booking confirmed!")
      }
    })
  }

  // Initialize calendar
  renderCalendar()
  console.log("Calendar initialized")
})
